-- Adminer 4.7.6 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `fdesk_demo` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `fdesk_demo`;

CREATE TABLE `accounts_payment_methods` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(140) NOT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `accounts_payment_methods` (`id`, `code`, `name`, `is_default`, `fdesk_user`, `created_at`, `updated_at`) VALUES
(3,	'Cash',	'Cash',	NULL,	0,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(4,	'MPesa',	'M-Pesa',	NULL,	0,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(5,	'CRTC',	'Credit Card',	NULL,	0,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(6,	'DBTC',	'Debit Card',	NULL,	0,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(7,	'GVCR',	'Gift Voucher',	NULL,	0,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(8,	'CHQ',	'Cheque',	NULL,	0,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00');

CREATE TABLE `accounts_taxes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) DEFAULT NULL,
  `tax_identifier` varchar(140) NOT NULL,
  `tax_rate` decimal(10,0) NOT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `accounts_taxes` (`id`, `code`, `tax_identifier`, `tax_rate`, `fdesk_user`, `created_at`, `updated_at`) VALUES
(1,	NULL,	'Vat',	6,	0,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(2,	NULL,	'Catering levy',	2,	0,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00');

CREATE TABLE `bank_account` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(140) NOT NULL,
  `account_number` varchar(20) NOT NULL,
  `financial_institution` varchar(140) NOT NULL,
  `starting_bal` decimal(10,0) DEFAULT '0',
  `starting_date` date DEFAULT NULL,
  `i_banking_na` tinyint(4) DEFAULT NULL,
  `last_statement_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `bank_deposit` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `payer` varchar(50) NOT NULL,
  `gl_account_id` int(11) DEFAULT NULL,
  `amount` decimal(10,0) NOT NULL,
  `tax_id` int(11) NOT NULL,
  `bank_account_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `bank_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(20) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `payee` varchar(50) DEFAULT NULL,
  `gl_account_id` int(11) DEFAULT NULL,
  `amount` decimal(14,6) NOT NULL,
  `tax_id` int(11) DEFAULT NULL,
  `bank_account_id` int(11) DEFAULT NULL COMMENT 'Paid from',
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `bank_receipt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `payer` varchar(50) NOT NULL,
  `gl_account_id` int(11) DEFAULT NULL,
  `amount` decimal(10,0) NOT NULL,
  `tax_id` int(11) DEFAULT NULL,
  `bank_account_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `bank_receipt` (`id`, `reference`, `date`, `payer`, `gl_account_id`, `amount`, `tax_id`, `bank_account_id`, `description`, `fdesk_user`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'12345',	'2020-02-06',	'Manager',	NULL,	451,	NULL,	1,	'Cash to bank',	1,	'2020-02-06 11:15:33',	'2020-02-06 11:15:33',	NULL);

CREATE TABLE `bank_transfer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(20) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `ba_paid_from` int(11) NOT NULL,
  `ba_paid_to` int(11) NOT NULL COMMENT 'Received in',
  `amount` decimal(14,6) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `business` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `business_name` varchar(140) NOT NULL,
  `trading_name` varchar(140) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `tax_identifier` varchar(20) DEFAULT NULL,
  `business_type` varchar(140) NOT NULL,
  `currency_symbol` char(3) DEFAULT NULL,
  `email_address` varchar(140) NOT NULL,
  `phone_number` varchar(140) DEFAULT NULL,
  `business_logo` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `business` (`id`, `business_name`, `trading_name`, `address`, `tax_identifier`, `business_type`, `currency_symbol`, `email_address`, `phone_number`, `business_logo`) VALUES
(1,	'Suhufi Palace Hotel',	'Suhufi Palace Hotel',	'Abdul Nassir Rd. (Bondeni) - Mombasa Kenya',	'',	'PO',	'KES',	'reservations@suhufihotel.co.ke',	'',	'uploads/suhufi_hotel.png');

CREATE TABLE `cash_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `starting_bal` decimal(14,6) DEFAULT NULL,
  `starting_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `cash_payment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `reference` int(11) NOT NULL,
  `date` date NOT NULL,
  `payee` varchar(50) NOT NULL,
  `gl_account_id` int(11) DEFAULT NULL,
  `amount` decimal(10,0) NOT NULL,
  `tax_id` int(11) DEFAULT NULL,
  `bank_account_id` int(11) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `cash_payment` (`id`, `reference`, `date`, `payee`, `gl_account_id`, `amount`, `tax_id`, `bank_account_id`, `description`, `fdesk_user`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	1003,	'2020-02-06',	'Mdee',	NULL,	230,	NULL,	NULL,	'Sabuni',	1,	'2020-01-24 16:38:54',	'2020-02-06 11:18:14',	NULL),
(2,	1002,	'2020-01-24',	'Cleaning Detergent',	NULL,	1000,	NULL,	NULL,	'Washroom cleaning agents',	1,	'2020-01-24 16:40:03',	'2020-01-24 16:40:03',	NULL);

CREATE TABLE `cash_receipt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `reference` int(11) NOT NULL,
  `bill_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `payer` varchar(50) NOT NULL,
  `gl_account_id` int(11) DEFAULT NULL,
  `amount` decimal(10,0) NOT NULL,
  `tax_id` int(11) DEFAULT NULL,
  `bank_account_id` int(11) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `cash_receipt` (`id`, `reference`, `bill_id`, `date`, `payer`, `gl_account_id`, `amount`, `tax_id`, `bank_account_id`, `description`, `fdesk_user`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	10001,	2,	'2020-02-06',	'Mary Kilobi',	NULL,	2500,	0,	NULL,	'Accommodation for Room no. 206',	1,	'2020-02-06 11:29:06',	'2020-02-06 11:29:06',	NULL),
(2,	10002,	1,	'2020-02-06',	'Dan Kim',	NULL,	2500,	0,	NULL,	'Accommodation for Room no. 405',	1,	'2020-02-06 11:30:25',	'2020-02-06 11:30:25',	NULL),
(3,	10003,	1,	'2020-02-06',	'Dan Kim',	NULL,	0,	0,	NULL,	'Accommodation for Room no. 405',	1,	'2020-02-06 11:30:32',	'2020-02-06 11:30:32',	NULL),
(4,	10004,	1,	'2020-02-06',	'Dan Kim',	NULL,	0,	0,	NULL,	'Accommodation for Room no. 405',	1,	'2020-02-06 11:34:03',	'2020-02-06 11:34:03',	NULL),
(5,	10005,	1,	'2020-02-06',	'Dan Kim',	NULL,	0,	0,	NULL,	'Accommodation for Room no. 405',	1,	'2020-02-06 11:34:08',	'2020-02-06 11:34:08',	NULL),
(6,	10006,	1,	'2020-02-06',	'Dan Kim',	NULL,	0,	0,	NULL,	'Accommodation for Room no. 405',	1,	'2020-02-06 11:34:56',	'2020-02-06 11:34:56',	NULL);

CREATE TABLE `cash_transfer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(20) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `ba_paid_from` int(11) NOT NULL,
  `ba_paid_to` int(11) NOT NULL COMMENT 'Received in',
  `amount` decimal(14,6) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


SET NAMES utf8mb4;

CREATE TABLE `countries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `iso_3166_2` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `iso_3166_3` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `capital` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `citizenship` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_sub_unit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_symbol` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_decimals` int(11) DEFAULT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `region_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sub_region_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `eea` tinyint(1) NOT NULL DEFAULT '0',
  `calling_code` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flag` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `countries` (`id`, `name`, `iso_3166_2`, `iso_3166_3`, `capital`, `citizenship`, `country_code`, `currency`, `currency_code`, `currency_sub_unit`, `currency_symbol`, `currency_decimals`, `full_name`, `region_code`, `sub_region_code`, `eea`, `calling_code`, `flag`, `created_at`, `updated_at`) VALUES
(1,	'Afghanistan',	'AF',	'AFG',	'Kabul',	'Afghan',	'004',	'afghani',	'AFN',	'pul',	'؋',	2,	'Islamic Republic of Afghanistan',	'142',	'034',	0,	'93',	'AF.png',	'2020-01-03 16:43:34',	'2020-01-03 16:43:34'),
(2,	'Albania',	'AL',	'ALB',	'Tirana',	'Albanian',	'008',	'lek',	'ALL',	'(qindar (pl. qindarka))',	'Lek',	2,	'Republic of Albania',	'150',	'039',	0,	'355',	'AL.png',	'2020-01-03 16:43:34',	'2020-01-03 16:43:34'),
(3,	'Antarctica',	'AQ',	'ATA',	'Antartica',	'of Antartica',	'010',	'',	'',	'',	'',	2,	'Antarctica',	'',	'',	0,	'672',	'AQ.png',	'2020-01-03 16:43:35',	'2020-01-03 16:43:35'),
(4,	'Algeria',	'DZ',	'DZA',	'Algiers',	'Algerian',	'012',	'Algerian dinar',	'DZD',	'centime',	'DZD',	2,	'People’s Democratic Republic of Algeria',	'002',	'015',	0,	'213',	'DZ.png',	'2020-01-03 16:43:36',	'2020-01-03 16:43:36'),
(5,	'American Samoa',	'AS',	'ASM',	'Pago Pago',	'American Samoan',	'016',	'US dollar',	'USD',	'cent',	'$',	2,	'Territory of American',	'009',	'061',	0,	'1',	'AS.png',	'2020-01-03 16:43:36',	'2020-01-03 16:43:36'),
(6,	'Andorra',	'AD',	'AND',	'Andorra la Vella',	'Andorran',	'020',	'euro',	'EUR',	'cent',	'€',	2,	'Principality of Andorra',	'150',	'039',	0,	'376',	'AD.png',	'2020-01-03 16:43:37',	'2020-01-03 16:43:37'),
(7,	'Angola',	'AO',	'AGO',	'Luanda',	'Angolan',	'024',	'kwanza',	'AOA',	'cêntimo',	'Kz',	2,	'Republic of Angola',	'002',	'017',	0,	'244',	'AO.png',	'2020-01-03 16:43:38',	'2020-01-03 16:43:38'),
(8,	'Antigua and Barbuda',	'AG',	'ATG',	'St John’s',	'of Antigua and Barbuda',	'028',	'East Caribbean dollar',	'XCD',	'cent',	'$',	2,	'Antigua and Barbuda',	'019',	'029',	0,	'1',	'AG.png',	'2020-01-03 16:43:39',	'2020-01-03 16:43:39'),
(9,	'Azerbaijan',	'AZ',	'AZE',	'Baku',	'Azerbaijani',	'031',	'Azerbaijani manat',	'AZN',	'kepik (inv.)',	'ман',	2,	'Republic of Azerbaijan',	'142',	'145',	0,	'994',	'AZ.png',	'2020-01-03 16:43:39',	'2020-01-03 16:43:39'),
(10,	'Argentina',	'AR',	'ARG',	'Buenos Aires',	'Argentinian',	'032',	'Argentine peso',	'ARS',	'centavo',	'$',	2,	'Argentine Republic',	'019',	'005',	0,	'54',	'AR.png',	'2020-01-03 16:43:39',	'2020-01-03 16:43:39'),
(11,	'Australia',	'AU',	'AUS',	'Canberra',	'Australian',	'036',	'Australian dollar',	'AUD',	'cent',	'$',	2,	'Commonwealth of Australia',	'009',	'053',	0,	'61',	'AU.png',	'2020-01-03 16:43:39',	'2020-01-03 16:43:39'),
(12,	'Austria',	'AT',	'AUT',	'Vienna',	'Austrian',	'040',	'euro',	'EUR',	'cent',	'€',	2,	'Republic of Austria',	'150',	'155',	1,	'43',	'AT.png',	'2020-01-03 16:43:40',	'2020-01-03 16:43:40'),
(13,	'Bahamas',	'BS',	'BHS',	'Nassau',	'Bahamian',	'044',	'Bahamian dollar',	'BSD',	'cent',	'$',	2,	'Commonwealth of the Bahamas',	'019',	'029',	0,	'1',	'BS.png',	'2020-01-03 16:43:40',	'2020-01-03 16:43:40'),
(14,	'Bahrain',	'BH',	'BHR',	'Manama',	'Bahraini',	'048',	'Bahraini dinar',	'BHD',	'fils (inv.)',	'BHD',	3,	'Kingdom of Bahrain',	'142',	'145',	0,	'973',	'BH.png',	'2020-01-03 16:43:40',	'2020-01-03 16:43:40'),
(15,	'Bangladesh',	'BD',	'BGD',	'Dhaka',	'Bangladeshi',	'050',	'taka (inv.)',	'BDT',	'poisha (inv.)',	'BDT',	2,	'People’s Republic of Bangladesh',	'142',	'034',	0,	'880',	'BD.png',	'2020-01-03 16:43:40',	'2020-01-03 16:43:40'),
(16,	'Armenia',	'AM',	'ARM',	'Yerevan',	'Armenian',	'051',	'dram (inv.)',	'AMD',	'luma',	'AMD',	2,	'Republic of Armenia',	'142',	'145',	0,	'374',	'AM.png',	'2020-01-03 16:43:40',	'2020-01-03 16:43:40'),
(17,	'Barbados',	'BB',	'BRB',	'Bridgetown',	'Barbadian',	'052',	'Barbados dollar',	'BBD',	'cent',	'$',	2,	'Barbados',	'019',	'029',	0,	'1',	'BB.png',	'2020-01-03 16:43:40',	'2020-01-03 16:43:40'),
(18,	'Belgium',	'BE',	'BEL',	'Brussels',	'Belgian',	'056',	'euro',	'EUR',	'cent',	'€',	2,	'Kingdom of Belgium',	'150',	'155',	1,	'32',	'BE.png',	'2020-01-03 16:43:40',	'2020-01-03 16:43:40'),
(19,	'Bermuda',	'BM',	'BMU',	'Hamilton',	'Bermudian',	'060',	'Bermuda dollar',	'BMD',	'cent',	'$',	2,	'Bermuda',	'019',	'021',	0,	'1',	'BM.png',	'2020-01-03 16:43:40',	'2020-01-03 16:43:40'),
(20,	'Bhutan',	'BT',	'BTN',	'Thimphu',	'Bhutanese',	'064',	'ngultrum (inv.)',	'BTN',	'chhetrum (inv.)',	'BTN',	2,	'Kingdom of Bhutan',	'142',	'034',	0,	'975',	'BT.png',	'2020-01-03 16:43:40',	'2020-01-03 16:43:40'),
(21,	'Bolivia, Plurinational State of',	'BO',	'BOL',	'Sucre (BO1)',	'Bolivian',	'068',	'boliviano',	'BOB',	'centavo',	'$b',	2,	'Plurinational State of Bolivia',	'019',	'005',	0,	'591',	'BO.png',	'2020-01-03 16:43:40',	'2020-01-03 16:43:40'),
(22,	'Bosnia and Herzegovina',	'BA',	'BIH',	'Sarajevo',	'of Bosnia and Herzegovina',	'070',	'convertible mark',	'BAM',	'fening',	'KM',	2,	'Bosnia and Herzegovina',	'150',	'039',	0,	'387',	'BA.png',	'2020-01-03 16:43:40',	'2020-01-03 16:43:40'),
(23,	'Botswana',	'BW',	'BWA',	'Gaborone',	'Botswanan',	'072',	'pula (inv.)',	'BWP',	'thebe (inv.)',	'P',	2,	'Republic of Botswana',	'002',	'018',	0,	'267',	'BW.png',	'2020-01-03 16:43:41',	'2020-01-03 16:43:41'),
(24,	'Bouvet Island',	'BV',	'BVT',	'Bouvet island',	'of Bouvet island',	'074',	'',	'',	'',	'kr',	2,	'Bouvet Island',	'',	'',	0,	'47',	'BV.png',	'2020-01-03 16:43:41',	'2020-01-03 16:43:41'),
(25,	'Brazil',	'BR',	'BRA',	'Brasilia',	'Brazilian',	'076',	'real (pl. reais)',	'BRL',	'centavo',	'R$',	2,	'Federative Republic of Brazil',	'019',	'005',	0,	'55',	'BR.png',	'2020-01-03 16:43:41',	'2020-01-03 16:43:41'),
(26,	'Belize',	'BZ',	'BLZ',	'Belmopan',	'Belizean',	'084',	'Belize dollar',	'BZD',	'cent',	'BZ$',	2,	'Belize',	'019',	'013',	0,	'501',	'BZ.png',	'2020-01-03 16:43:41',	'2020-01-03 16:43:41'),
(27,	'British Indian Ocean Territory',	'IO',	'IOT',	'Diego Garcia',	'Changosian',	'086',	'US dollar',	'USD',	'cent',	'$',	2,	'British Indian Ocean Territory',	'',	'',	0,	'246',	'IO.png',	'2020-01-03 16:43:41',	'2020-01-03 16:43:41'),
(28,	'Solomon Islands',	'SB',	'SLB',	'Honiara',	'Solomon Islander',	'090',	'Solomon Islands dollar',	'SBD',	'cent',	'$',	2,	'Solomon Islands',	'009',	'054',	0,	'677',	'SB.png',	'2020-01-03 16:43:41',	'2020-01-03 16:43:41'),
(29,	'Virgin Islands, British',	'VG',	'VGB',	'Road Town',	'British Virgin Islander;',	'092',	'US dollar',	'USD',	'cent',	'$',	2,	'British Virgin Islands',	'019',	'029',	0,	'1',	'VG.png',	'2020-01-03 16:43:41',	'2020-01-03 16:43:41'),
(30,	'Brunei Darussalam',	'BN',	'BRN',	'Bandar Seri Begawan',	'Bruneian',	'096',	'Brunei dollar',	'BND',	'sen (inv.)',	'$',	2,	'Brunei Darussalam',	'142',	'035',	0,	'673',	'BN.png',	'2020-01-03 16:43:41',	'2020-01-03 16:43:41'),
(31,	'Bulgaria',	'BG',	'BGR',	'Sofia',	'Bulgarian',	'100',	'lev (pl. leva)',	'BGN',	'stotinka',	'лв',	2,	'Republic of Bulgaria',	'150',	'151',	1,	'359',	'BG.png',	'2020-01-03 16:43:41',	'2020-01-03 16:43:41'),
(32,	'Myanmar',	'MM',	'MMR',	'Yangon',	'Burmese',	'104',	'kyat',	'MMK',	'pya',	'K',	2,	'Union of Myanmar/',	'142',	'035',	0,	'95',	'MM.png',	'2020-01-03 16:43:41',	'2020-01-03 16:43:41'),
(33,	'Burundi',	'BI',	'BDI',	'Bujumbura',	'Burundian',	'108',	'Burundi franc',	'BIF',	'centime',	'BIF',	0,	'Republic of Burundi',	'002',	'014',	0,	'257',	'BI.png',	'2020-01-03 16:43:41',	'2020-01-03 16:43:41'),
(34,	'Belarus',	'BY',	'BLR',	'Minsk',	'Belarusian',	'112',	'Belarusian rouble',	'BYR',	'kopek',	'p.',	2,	'Republic of Belarus',	'150',	'151',	0,	'375',	'BY.png',	'2020-01-03 16:43:41',	'2020-01-03 16:43:41'),
(35,	'Cambodia',	'KH',	'KHM',	'Phnom Penh',	'Cambodian',	'116',	'riel',	'KHR',	'sen (inv.)',	'៛',	2,	'Kingdom of Cambodia',	'142',	'035',	0,	'855',	'KH.png',	'2020-01-03 16:43:41',	'2020-01-03 16:43:41'),
(36,	'Cameroon',	'CM',	'CMR',	'Yaoundé',	'Cameroonian',	'120',	'CFA franc (BEAC)',	'XAF',	'centime',	'FCF',	0,	'Republic of Cameroon',	'002',	'017',	0,	'237',	'CM.png',	'2020-01-03 16:43:41',	'2020-01-03 16:43:41'),
(37,	'Canada',	'CA',	'CAN',	'Ottawa',	'Canadian',	'124',	'Canadian dollar',	'CAD',	'cent',	'$',	2,	'Canada',	'019',	'021',	0,	'1',	'CA.png',	'2020-01-03 16:43:42',	'2020-01-03 16:43:42'),
(38,	'Cape Verde',	'CV',	'CPV',	'Praia',	'Cape Verdean',	'132',	'Cape Verde escudo',	'CVE',	'centavo',	'CVE',	2,	'Republic of Cape Verde',	'002',	'011',	0,	'238',	'CV.png',	'2020-01-03 16:43:42',	'2020-01-03 16:43:42'),
(39,	'Cayman Islands',	'KY',	'CYM',	'George Town',	'Caymanian',	'136',	'Cayman Islands dollar',	'KYD',	'cent',	'$',	2,	'Cayman Islands',	'019',	'029',	0,	'1',	'KY.png',	'2020-01-03 16:43:42',	'2020-01-03 16:43:42'),
(40,	'Central African Republic',	'CF',	'CAF',	'Bangui',	'Central African',	'140',	'CFA franc (BEAC)',	'XAF',	'centime',	'CFA',	0,	'Central African Republic',	'002',	'017',	0,	'236',	'CF.png',	'2020-01-03 16:43:42',	'2020-01-03 16:43:42'),
(41,	'Sri Lanka',	'LK',	'LKA',	'Colombo',	'Sri Lankan',	'144',	'Sri Lankan rupee',	'LKR',	'cent',	'₨',	2,	'Democratic Socialist Republic of Sri Lanka',	'142',	'034',	0,	'94',	'LK.png',	'2020-01-03 16:43:42',	'2020-01-03 16:43:42'),
(42,	'Chad',	'TD',	'TCD',	'N’Djamena',	'Chadian',	'148',	'CFA franc (BEAC)',	'XAF',	'centime',	'XAF',	0,	'Republic of Chad',	'002',	'017',	0,	'235',	'TD.png',	'2020-01-03 16:43:42',	'2020-01-03 16:43:42'),
(43,	'Chile',	'CL',	'CHL',	'Santiago',	'Chilean',	'152',	'Chilean peso',	'CLP',	'centavo',	'CLP',	0,	'Republic of Chile',	'019',	'005',	0,	'56',	'CL.png',	'2020-01-03 16:43:42',	'2020-01-03 16:43:42'),
(44,	'China',	'CN',	'CHN',	'Beijing',	'Chinese',	'156',	'renminbi-yuan (inv.)',	'CNY',	'jiao (10)',	'¥',	2,	'People’s Republic of China',	'142',	'030',	0,	'86',	'CN.png',	'2020-01-03 16:43:42',	'2020-01-03 16:43:42'),
(45,	'Taiwan, Province of China',	'TW',	'TWN',	'Taipei',	'Taiwanese',	'158',	'new Taiwan dollar',	'TWD',	'fen (inv.)',	'NT$',	2,	'Republic of China, Taiwan (TW1)',	'142',	'030',	0,	'886',	'TW.png',	'2020-01-03 16:43:42',	'2020-01-03 16:43:42'),
(46,	'Christmas Island',	'CX',	'CXR',	'Flying Fish Cove',	'Christmas Islander',	'162',	'Australian dollar',	'AUD',	'cent',	'$',	2,	'Christmas Island Territory',	'',	'',	0,	'61',	'CX.png',	'2020-01-03 16:43:42',	'2020-01-03 16:43:42'),
(47,	'Cocos (Keeling) Islands',	'CC',	'CCK',	'Bantam',	'Cocos Islander',	'166',	'Australian dollar',	'AUD',	'cent',	'$',	2,	'Territory of Cocos (Keeling) Islands',	'',	'',	0,	'61',	'CC.png',	'2020-01-03 16:43:42',	'2020-01-03 16:43:42'),
(48,	'Colombia',	'CO',	'COL',	'Santa Fe de Bogotá',	'Colombian',	'170',	'Colombian peso',	'COP',	'centavo',	'$',	2,	'Republic of Colombia',	'019',	'005',	0,	'57',	'CO.png',	'2020-01-03 16:43:42',	'2020-01-03 16:43:42'),
(49,	'Comoros',	'KM',	'COM',	'Moroni',	'Comorian',	'174',	'Comorian franc',	'KMF',	'',	'KMF',	0,	'Union of the Comoros',	'002',	'014',	0,	'269',	'KM.png',	'2020-01-03 16:43:42',	'2020-01-03 16:43:42'),
(50,	'Mayotte',	'YT',	'MYT',	'Mamoudzou',	'Mahorais',	'175',	'euro',	'EUR',	'cent',	'€',	2,	'Departmental Collectivity of Mayotte',	'002',	'014',	0,	'262',	'YT.png',	'2020-01-03 16:43:42',	'2020-01-03 16:43:42'),
(51,	'Congo',	'CG',	'COG',	'Brazzaville',	'Congolese',	'178',	'CFA franc (BEAC)',	'XAF',	'centime',	'FCF',	0,	'Republic of the Congo',	'002',	'017',	0,	'242',	'CG.png',	'2020-01-03 16:43:43',	'2020-01-03 16:43:43'),
(52,	'Congo, the Democratic Republic of the',	'CD',	'COD',	'Kinshasa',	'Congolese',	'180',	'Congolese franc',	'CDF',	'centime',	'CDF',	2,	'Democratic Republic of the Congo',	'002',	'017',	0,	'243',	'CD.png',	'2020-01-03 16:43:43',	'2020-01-03 16:43:43'),
(53,	'Cook Islands',	'CK',	'COK',	'Avarua',	'Cook Islander',	'184',	'New Zealand dollar',	'NZD',	'cent',	'$',	2,	'Cook Islands',	'009',	'061',	0,	'682',	'CK.png',	'2020-01-03 16:43:43',	'2020-01-03 16:43:43'),
(54,	'Costa Rica',	'CR',	'CRI',	'San José',	'Costa Rican',	'188',	'Costa Rican colón (pl. colones)',	'CRC',	'céntimo',	'₡',	2,	'Republic of Costa Rica',	'019',	'013',	0,	'506',	'CR.png',	'2020-01-03 16:43:43',	'2020-01-03 16:43:43'),
(55,	'Croatia',	'HR',	'HRV',	'Zagreb',	'Croatian',	'191',	'kuna (inv.)',	'HRK',	'lipa (inv.)',	'kn',	2,	'Republic of Croatia',	'150',	'039',	1,	'385',	'HR.png',	'2020-01-03 16:43:43',	'2020-01-03 16:43:43'),
(56,	'Cuba',	'CU',	'CUB',	'Havana',	'Cuban',	'192',	'Cuban peso',	'CUP',	'centavo',	'₱',	2,	'Republic of Cuba',	'019',	'029',	0,	'53',	'CU.png',	'2020-01-03 16:43:43',	'2020-01-03 16:43:43'),
(57,	'Cyprus',	'CY',	'CYP',	'Nicosia',	'Cypriot',	'196',	'euro',	'EUR',	'cent',	'CYP',	2,	'Republic of Cyprus',	'142',	'145',	1,	'357',	'CY.png',	'2020-01-03 16:43:43',	'2020-01-03 16:43:43'),
(58,	'Czech Republic',	'CZ',	'CZE',	'Prague',	'Czech',	'203',	'Czech koruna (pl. koruny)',	'CZK',	'halér',	'Kč',	2,	'Czech Republic',	'150',	'151',	1,	'420',	'CZ.png',	'2020-01-03 16:43:43',	'2020-01-03 16:43:43'),
(59,	'Benin',	'BJ',	'BEN',	'Porto Novo (BJ1)',	'Beninese',	'204',	'CFA franc (BCEAO)',	'XOF',	'centime',	'XOF',	0,	'Republic of Benin',	'002',	'011',	0,	'229',	'BJ.png',	'2020-01-03 16:43:44',	'2020-01-03 16:43:44'),
(60,	'Denmark',	'DK',	'DNK',	'Copenhagen',	'Danish',	'208',	'Danish krone',	'DKK',	'øre (inv.)',	'kr',	2,	'Kingdom of Denmark',	'150',	'154',	1,	'45',	'DK.png',	'2020-01-03 16:43:44',	'2020-01-03 16:43:44'),
(61,	'Dominica',	'DM',	'DMA',	'Roseau',	'Dominican',	'212',	'East Caribbean dollar',	'XCD',	'cent',	'$',	2,	'Commonwealth of Dominica',	'019',	'029',	0,	'1',	'DM.png',	'2020-01-03 16:43:44',	'2020-01-03 16:43:44'),
(62,	'Dominican Republic',	'DO',	'DOM',	'Santo Domingo',	'Dominican',	'214',	'Dominican peso',	'DOP',	'centavo',	'RD$',	2,	'Dominican Republic',	'019',	'029',	0,	'1',	'DO.png',	'2020-01-03 16:43:44',	'2020-01-03 16:43:44'),
(63,	'Ecuador',	'EC',	'ECU',	'Quito',	'Ecuadorian',	'218',	'US dollar',	'USD',	'cent',	'$',	2,	'Republic of Ecuador',	'019',	'005',	0,	'593',	'EC.png',	'2020-01-03 16:43:44',	'2020-01-03 16:43:44'),
(64,	'El Salvador',	'SV',	'SLV',	'San Salvador',	'Salvadoran',	'222',	'Salvadorian colón (pl. colones)',	'SVC',	'centavo',	'$',	2,	'Republic of El Salvador',	'019',	'013',	0,	'503',	'SV.png',	'2020-01-03 16:43:44',	'2020-01-03 16:43:44'),
(65,	'Equatorial Guinea',	'GQ',	'GNQ',	'Malabo',	'Equatorial Guinean',	'226',	'CFA franc (BEAC)',	'XAF',	'centime',	'FCF',	2,	'Republic of Equatorial Guinea',	'002',	'017',	0,	'240',	'GQ.png',	'2020-01-03 16:43:44',	'2020-01-03 16:43:44'),
(66,	'Ethiopia',	'ET',	'ETH',	'Addis Ababa',	'Ethiopian',	'231',	'birr (inv.)',	'ETB',	'cent',	'ETB',	2,	'Federal Democratic Republic of Ethiopia',	'002',	'014',	0,	'251',	'ET.png',	'2020-01-03 16:43:44',	'2020-01-03 16:43:44'),
(67,	'Eritrea',	'ER',	'ERI',	'Asmara',	'Eritrean',	'232',	'nakfa',	'ERN',	'cent',	'Nfk',	2,	'State of Eritrea',	'002',	'014',	0,	'291',	'ER.png',	'2020-01-03 16:43:44',	'2020-01-03 16:43:44'),
(68,	'Estonia',	'EE',	'EST',	'Tallinn',	'Estonian',	'233',	'euro',	'EUR',	'cent',	'kr',	2,	'Republic of Estonia',	'150',	'154',	1,	'372',	'EE.png',	'2020-01-03 16:43:45',	'2020-01-03 16:43:45'),
(69,	'Faroe Islands',	'FO',	'FRO',	'Tórshavn',	'Faeroese',	'234',	'Danish krone',	'DKK',	'øre (inv.)',	'kr',	2,	'Faeroe Islands',	'150',	'154',	0,	'298',	'FO.png',	'2020-01-03 16:43:45',	'2020-01-03 16:43:45'),
(70,	'Falkland Islands (Malvinas)',	'FK',	'FLK',	'Stanley',	'Falkland Islander',	'238',	'Falkland Islands pound',	'FKP',	'new penny',	'£',	2,	'Falkland Islands',	'019',	'005',	0,	'500',	'FK.png',	'2020-01-03 16:43:45',	'2020-01-03 16:43:45'),
(71,	'South Georgia and the South Sandwich Islands',	'GS',	'SGS',	'King Edward Point (Grytviken)',	'of South Georgia and the South Sandwich Islands',	'239',	'',	'',	'',	'£',	2,	'South Georgia and the South Sandwich Islands',	'',	'',	0,	'44',	'GS.png',	'2020-01-03 16:43:47',	'2020-01-03 16:43:47'),
(72,	'Fiji',	'FJ',	'FJI',	'Suva',	'Fijian',	'242',	'Fiji dollar',	'FJD',	'cent',	'$',	2,	'Republic of Fiji',	'009',	'054',	0,	'679',	'FJ.png',	'2020-01-03 16:43:48',	'2020-01-03 16:43:48'),
(73,	'Finland',	'FI',	'FIN',	'Helsinki',	'Finnish',	'246',	'euro',	'EUR',	'cent',	'€',	2,	'Republic of Finland',	'150',	'154',	1,	'358',	'FI.png',	'2020-01-03 16:43:48',	'2020-01-03 16:43:48'),
(74,	'Åland Islands',	'AX',	'ALA',	'Mariehamn',	'Åland Islander',	'248',	'euro',	'EUR',	'cent',	NULL,	NULL,	'Åland Islands',	'150',	'154',	0,	'358',	NULL,	'2020-01-03 16:43:48',	'2020-01-03 16:43:48'),
(75,	'France',	'FR',	'FRA',	'Paris',	'French',	'250',	'euro',	'EUR',	'cent',	'€',	2,	'French Republic',	'150',	'155',	1,	'33',	'FR.png',	'2020-01-03 16:43:49',	'2020-01-03 16:43:49'),
(76,	'French Guiana',	'GF',	'GUF',	'Cayenne',	'Guianese',	'254',	'euro',	'EUR',	'cent',	'€',	2,	'French Guiana',	'019',	'005',	0,	'594',	'GF.png',	'2020-01-03 16:43:49',	'2020-01-03 16:43:49'),
(77,	'French Polynesia',	'PF',	'PYF',	'Papeete',	'Polynesian',	'258',	'CFP franc',	'XPF',	'centime',	'XPF',	0,	'French Polynesia',	'009',	'061',	0,	'689',	'PF.png',	'2020-01-03 16:43:49',	'2020-01-03 16:43:49'),
(78,	'French Southern Territories',	'TF',	'ATF',	'Port-aux-Francais',	'of French Southern and Antarctic Lands',	'260',	'euro',	'EUR',	'cent',	'€',	2,	'French Southern and Antarctic Lands',	'',	'',	0,	'33',	'TF.png',	'2020-01-03 16:43:49',	'2020-01-03 16:43:49'),
(79,	'Djibouti',	'DJ',	'DJI',	'Djibouti',	'Djiboutian',	'262',	'Djibouti franc',	'DJF',	'',	'DJF',	0,	'Republic of Djibouti',	'002',	'014',	0,	'253',	'DJ.png',	'2020-01-03 16:43:49',	'2020-01-03 16:43:49'),
(80,	'Gabon',	'GA',	'GAB',	'Libreville',	'Gabonese',	'266',	'CFA franc (BEAC)',	'XAF',	'centime',	'FCF',	0,	'Gabonese Republic',	'002',	'017',	0,	'241',	'GA.png',	'2020-01-03 16:43:49',	'2020-01-03 16:43:49'),
(81,	'Georgia',	'GE',	'GEO',	'Tbilisi',	'Georgian',	'268',	'lari',	'GEL',	'tetri (inv.)',	'GEL',	2,	'Georgia',	'142',	'145',	0,	'995',	'GE.png',	'2020-01-03 16:43:50',	'2020-01-03 16:43:50'),
(82,	'Gambia',	'GM',	'GMB',	'Banjul',	'Gambian',	'270',	'dalasi (inv.)',	'GMD',	'butut',	'D',	2,	'Republic of the Gambia',	'002',	'011',	0,	'220',	'GM.png',	'2020-01-03 16:43:51',	'2020-01-03 16:43:51'),
(83,	'Palestinian Territory, Occupied',	'PS',	'PSE',	NULL,	'Palestinian',	'275',	NULL,	NULL,	NULL,	'₪',	2,	NULL,	'142',	'145',	0,	'970',	'PS.png',	'2020-01-03 16:43:51',	'2020-01-03 16:43:51'),
(84,	'Germany',	'DE',	'DEU',	'Berlin',	'German',	'276',	'euro',	'EUR',	'cent',	'€',	2,	'Federal Republic of Germany',	'150',	'155',	1,	'49',	'DE.png',	'2020-01-03 16:43:51',	'2020-01-03 16:43:51'),
(85,	'Ghana',	'GH',	'GHA',	'Accra',	'Ghanaian',	'288',	'Ghana cedi',	'GHS',	'pesewa',	'¢',	2,	'Republic of Ghana',	'002',	'011',	0,	'233',	'GH.png',	'2020-01-03 16:43:51',	'2020-01-03 16:43:51'),
(86,	'Gibraltar',	'GI',	'GIB',	'Gibraltar',	'Gibraltarian',	'292',	'Gibraltar pound',	'GIP',	'penny',	'£',	2,	'Gibraltar',	'150',	'039',	0,	'350',	'GI.png',	'2020-01-03 16:43:52',	'2020-01-03 16:43:52'),
(87,	'Kiribati',	'KI',	'KIR',	'Tarawa',	'Kiribatian',	'296',	'Australian dollar',	'AUD',	'cent',	'$',	2,	'Republic of Kiribati',	'009',	'057',	0,	'686',	'KI.png',	'2020-01-03 16:43:52',	'2020-01-03 16:43:52'),
(88,	'Greece',	'GR',	'GRC',	'Athens',	'Greek',	'300',	'euro',	'EUR',	'cent',	'€',	2,	'Hellenic Republic',	'150',	'039',	1,	'30',	'GR.png',	'2020-01-03 16:43:52',	'2020-01-03 16:43:52'),
(89,	'Greenland',	'GL',	'GRL',	'Nuuk',	'Greenlander',	'304',	'Danish krone',	'DKK',	'øre (inv.)',	'kr',	2,	'Greenland',	'019',	'021',	0,	'299',	'GL.png',	'2020-01-03 16:43:52',	'2020-01-03 16:43:52'),
(90,	'Grenada',	'GD',	'GRD',	'St George’s',	'Grenadian',	'308',	'East Caribbean dollar',	'XCD',	'cent',	'$',	2,	'Grenada',	'019',	'029',	0,	'1',	'GD.png',	'2020-01-03 16:43:52',	'2020-01-03 16:43:52'),
(91,	'Guadeloupe',	'GP',	'GLP',	'Basse Terre',	'Guadeloupean',	'312',	'euro',	'EUR',	'cent',	'€',	2,	'Guadeloupe',	'019',	'029',	0,	'590',	'GP.png',	'2020-01-03 16:43:52',	'2020-01-03 16:43:52'),
(92,	'Guam',	'GU',	'GUM',	'Agaña (Hagåtña)',	'Guamanian',	'316',	'US dollar',	'USD',	'cent',	'$',	2,	'Territory of Guam',	'009',	'057',	0,	'1',	'GU.png',	'2020-01-03 16:43:53',	'2020-01-03 16:43:53'),
(93,	'Guatemala',	'GT',	'GTM',	'Guatemala City',	'Guatemalan',	'320',	'quetzal (pl. quetzales)',	'GTQ',	'centavo',	'Q',	2,	'Republic of Guatemala',	'019',	'013',	0,	'502',	'GT.png',	'2020-01-03 16:43:53',	'2020-01-03 16:43:53'),
(94,	'Guinea',	'GN',	'GIN',	'Conakry',	'Guinean',	'324',	'Guinean franc',	'GNF',	'',	'GNF',	0,	'Republic of Guinea',	'002',	'011',	0,	'224',	'GN.png',	'2020-01-03 16:43:53',	'2020-01-03 16:43:53'),
(95,	'Guyana',	'GY',	'GUY',	'Georgetown',	'Guyanese',	'328',	'Guyana dollar',	'GYD',	'cent',	'$',	2,	'Cooperative Republic of Guyana',	'019',	'005',	0,	'592',	'GY.png',	'2020-01-03 16:43:53',	'2020-01-03 16:43:53'),
(96,	'Haiti',	'HT',	'HTI',	'Port-au-Prince',	'Haitian',	'332',	'gourde',	'HTG',	'centime',	'G',	2,	'Republic of Haiti',	'019',	'029',	0,	'509',	'HT.png',	'2020-01-03 16:43:53',	'2020-01-03 16:43:53'),
(97,	'Heard Island and McDonald Islands',	'HM',	'HMD',	'Territory of Heard Island and McDonald Islands',	'of Territory of Heard Island and McDonald Islands',	'334',	'',	'',	'',	'$',	2,	'Territory of Heard Island and McDonald Islands',	'',	'',	0,	'61',	'HM.png',	'2020-01-03 16:43:53',	'2020-01-03 16:43:53'),
(98,	'Holy See (Vatican City State)',	'VA',	'VAT',	'Vatican City',	'of the Holy See/of the Vatican',	'336',	'euro',	'EUR',	'cent',	'€',	2,	'the Holy See/ Vatican City State',	'150',	'039',	0,	'39',	'VA.png',	'2020-01-03 16:43:53',	'2020-01-03 16:43:53'),
(99,	'Honduras',	'HN',	'HND',	'Tegucigalpa',	'Honduran',	'340',	'lempira',	'HNL',	'centavo',	'L',	2,	'Republic of Honduras',	'019',	'013',	0,	'504',	'HN.png',	'2020-01-03 16:43:53',	'2020-01-03 16:43:53'),
(100,	'Hong Kong',	'HK',	'HKG',	'(HK3)',	'Hong Kong Chinese',	'344',	'Hong Kong dollar',	'HKD',	'cent',	'$',	2,	'Hong Kong Special Administrative Region of the People’s Republic of China (HK2)',	'142',	'030',	0,	'852',	'HK.png',	'2020-01-03 16:43:53',	'2020-01-03 16:43:53'),
(101,	'Hungary',	'HU',	'HUN',	'Budapest',	'Hungarian',	'348',	'forint (inv.)',	'HUF',	'(fillér (inv.))',	'Ft',	2,	'Republic of Hungary',	'150',	'151',	1,	'36',	'HU.png',	'2020-01-03 16:43:53',	'2020-01-03 16:43:53'),
(102,	'Iceland',	'IS',	'ISL',	'Reykjavik',	'Icelander',	'352',	'króna (pl. krónur)',	'ISK',	'',	'kr',	0,	'Republic of Iceland',	'150',	'154',	0,	'354',	'IS.png',	'2020-01-03 16:43:54',	'2020-01-03 16:43:54'),
(103,	'India',	'IN',	'IND',	'New Delhi',	'Indian',	'356',	'Indian rupee',	'INR',	'paisa',	'₹',	2,	'Republic of India',	'142',	'034',	0,	'91',	'IN.png',	'2020-01-03 16:43:54',	'2020-01-03 16:43:54'),
(104,	'Indonesia',	'ID',	'IDN',	'Jakarta',	'Indonesian',	'360',	'Indonesian rupiah (inv.)',	'IDR',	'sen (inv.)',	'Rp',	2,	'Republic of Indonesia',	'142',	'035',	0,	'62',	'ID.png',	'2020-01-03 16:43:54',	'2020-01-03 16:43:54'),
(105,	'Iran, Islamic Republic of',	'IR',	'IRN',	'Tehran',	'Iranian',	'364',	'Iranian rial',	'IRR',	'(dinar) (IR1)',	'﷼',	2,	'Islamic Republic of Iran',	'142',	'034',	0,	'98',	'IR.png',	'2020-01-03 16:43:54',	'2020-01-03 16:43:54'),
(106,	'Iraq',	'IQ',	'IRQ',	'Baghdad',	'Iraqi',	'368',	'Iraqi dinar',	'IQD',	'fils (inv.)',	'IQD',	3,	'Republic of Iraq',	'142',	'145',	0,	'964',	'IQ.png',	'2020-01-03 16:43:54',	'2020-01-03 16:43:54'),
(107,	'Ireland',	'IE',	'IRL',	'Dublin',	'Irish',	'372',	'euro',	'EUR',	'cent',	'€',	2,	'Ireland (IE1)',	'150',	'154',	1,	'353',	'IE.png',	'2020-01-03 16:43:54',	'2020-01-03 16:43:54'),
(108,	'Israel',	'IL',	'ISR',	'(IL1)',	'Israeli',	'376',	'shekel',	'ILS',	'agora',	'₪',	2,	'State of Israel',	'142',	'145',	0,	'972',	'IL.png',	'2020-01-03 16:43:54',	'2020-01-03 16:43:54'),
(109,	'Italy',	'IT',	'ITA',	'Rome',	'Italian',	'380',	'euro',	'EUR',	'cent',	'€',	2,	'Italian Republic',	'150',	'039',	1,	'39',	'IT.png',	'2020-01-03 16:43:54',	'2020-01-03 16:43:54'),
(110,	'Côte d\'Ivoire',	'CI',	'CIV',	'Yamoussoukro (CI1)',	'Ivorian',	'384',	'CFA franc (BCEAO)',	'XOF',	'centime',	'XOF',	0,	'Republic of Côte d’Ivoire',	'002',	'011',	0,	'225',	'CI.png',	'2020-01-03 16:43:54',	'2020-01-03 16:43:54'),
(111,	'Jamaica',	'JM',	'JAM',	'Kingston',	'Jamaican',	'388',	'Jamaica dollar',	'JMD',	'cent',	'$',	2,	'Jamaica',	'019',	'029',	0,	'1',	'JM.png',	'2020-01-03 16:43:55',	'2020-01-03 16:43:55'),
(112,	'Japan',	'JP',	'JPN',	'Tokyo',	'Japanese',	'392',	'yen (inv.)',	'JPY',	'(sen (inv.)) (JP1)',	'¥',	0,	'Japan',	'142',	'030',	0,	'81',	'JP.png',	'2020-01-03 16:43:55',	'2020-01-03 16:43:55'),
(113,	'Kazakhstan',	'KZ',	'KAZ',	'Astana',	'Kazakh',	'398',	'tenge (inv.)',	'KZT',	'tiyn',	'лв',	2,	'Republic of Kazakhstan',	'142',	'143',	0,	'7',	'KZ.png',	'2020-01-03 16:43:55',	'2020-01-03 16:43:55'),
(114,	'Jordan',	'JO',	'JOR',	'Amman',	'Jordanian',	'400',	'Jordanian dinar',	'JOD',	'100 qirsh',	'JOD',	2,	'Hashemite Kingdom of Jordan',	'142',	'145',	0,	'962',	'JO.png',	'2020-01-03 16:43:55',	'2020-01-03 16:43:55'),
(115,	'Kenya',	'KE',	'KEN',	'Nairobi',	'Kenyan',	'404',	'Kenyan shilling',	'KES',	'cent',	'KES',	2,	'Republic of Kenya',	'002',	'014',	0,	'254',	'KE.png',	'2020-01-03 16:43:55',	'2020-01-03 16:43:55'),
(116,	'Korea, Democratic People\'s Republic of',	'KP',	'PRK',	'Pyongyang',	'North Korean',	'408',	'North Korean won (inv.)',	'KPW',	'chun (inv.)',	'₩',	2,	'Democratic People’s Republic of Korea',	'142',	'030',	0,	'850',	'KP.png',	'2020-01-03 16:43:55',	'2020-01-03 16:43:55'),
(117,	'Korea, Republic of',	'KR',	'KOR',	'Seoul',	'South Korean',	'410',	'South Korean won (inv.)',	'KRW',	'(chun (inv.))',	'₩',	0,	'Republic of Korea',	'142',	'030',	0,	'82',	'KR.png',	'2020-01-03 16:43:56',	'2020-01-03 16:43:56'),
(118,	'Kuwait',	'KW',	'KWT',	'Kuwait City',	'Kuwaiti',	'414',	'Kuwaiti dinar',	'KWD',	'fils (inv.)',	'KWD',	3,	'State of Kuwait',	'142',	'145',	0,	'965',	'KW.png',	'2020-01-03 16:43:56',	'2020-01-03 16:43:56'),
(119,	'Kyrgyzstan',	'KG',	'KGZ',	'Bishkek',	'Kyrgyz',	'417',	'som',	'KGS',	'tyiyn',	'лв',	2,	'Kyrgyz Republic',	'142',	'143',	0,	'996',	'KG.png',	'2020-01-03 16:43:56',	'2020-01-03 16:43:56'),
(120,	'Lao People\'s Democratic Republic',	'LA',	'LAO',	'Vientiane',	'Lao',	'418',	'kip (inv.)',	'LAK',	'(at (inv.))',	'₭',	0,	'Lao People’s Democratic Republic',	'142',	'035',	0,	'856',	'LA.png',	'2020-01-03 16:43:56',	'2020-01-03 16:43:56'),
(121,	'Lebanon',	'LB',	'LBN',	'Beirut',	'Lebanese',	'422',	'Lebanese pound',	'LBP',	'(piastre)',	'£',	2,	'Lebanese Republic',	'142',	'145',	0,	'961',	'LB.png',	'2020-01-03 16:43:56',	'2020-01-03 16:43:56'),
(122,	'Lesotho',	'LS',	'LSO',	'Maseru',	'Basotho',	'426',	'loti (pl. maloti)',	'LSL',	'sente',	'L',	2,	'Kingdom of Lesotho',	'002',	'018',	0,	'266',	'LS.png',	'2020-01-03 16:43:56',	'2020-01-03 16:43:56'),
(123,	'Latvia',	'LV',	'LVA',	'Riga',	'Latvian',	'428',	'euro',	'EUR',	'cent',	'Ls',	2,	'Republic of Latvia',	'150',	'154',	1,	'371',	'LV.png',	'2020-01-03 16:43:56',	'2020-01-03 16:43:56'),
(124,	'Liberia',	'LR',	'LBR',	'Monrovia',	'Liberian',	'430',	'Liberian dollar',	'LRD',	'cent',	'$',	2,	'Republic of Liberia',	'002',	'011',	0,	'231',	'LR.png',	'2020-01-03 16:43:57',	'2020-01-03 16:43:57'),
(125,	'Libya',	'LY',	'LBY',	'Tripoli',	'Libyan',	'434',	'Libyan dinar',	'LYD',	'dirham',	'LYD',	3,	'Socialist People’s Libyan Arab Jamahiriya',	'002',	'015',	0,	'218',	'LY.png',	'2020-01-03 16:43:57',	'2020-01-03 16:43:57'),
(126,	'Liechtenstein',	'LI',	'LIE',	'Vaduz',	'Liechtensteiner',	'438',	'Swiss franc',	'CHF',	'centime',	'CHF',	2,	'Principality of Liechtenstein',	'150',	'155',	0,	'423',	'LI.png',	'2020-01-03 16:43:57',	'2020-01-03 16:43:57'),
(127,	'Lithuania',	'LT',	'LTU',	'Vilnius',	'Lithuanian',	'440',	'euro',	'EUR',	'cent',	'Lt',	2,	'Republic of Lithuania',	'150',	'154',	1,	'370',	'LT.png',	'2020-01-03 16:43:57',	'2020-01-03 16:43:57'),
(128,	'Luxembourg',	'LU',	'LUX',	'Luxembourg',	'Luxembourger',	'442',	'euro',	'EUR',	'cent',	'€',	2,	'Grand Duchy of Luxembourg',	'150',	'155',	1,	'352',	'LU.png',	'2020-01-03 16:43:57',	'2020-01-03 16:43:57'),
(129,	'Macao',	'MO',	'MAC',	'Macao (MO3)',	'Macanese',	'446',	'pataca',	'MOP',	'avo',	'MOP',	2,	'Macao Special Administrative Region of the People’s Republic of China (MO2)',	'142',	'030',	0,	'853',	'MO.png',	'2020-01-03 16:43:58',	'2020-01-03 16:43:58'),
(130,	'Madagascar',	'MG',	'MDG',	'Antananarivo',	'Malagasy',	'450',	'ariary',	'MGA',	'iraimbilanja (inv.)',	'MGA',	2,	'Republic of Madagascar',	'002',	'014',	0,	'261',	'MG.png',	'2020-01-03 16:43:58',	'2020-01-03 16:43:58'),
(131,	'Malawi',	'MW',	'MWI',	'Lilongwe',	'Malawian',	'454',	'Malawian kwacha (inv.)',	'MWK',	'tambala (inv.)',	'MK',	2,	'Republic of Malawi',	'002',	'014',	0,	'265',	'MW.png',	'2020-01-03 16:43:58',	'2020-01-03 16:43:58'),
(132,	'Malaysia',	'MY',	'MYS',	'Kuala Lumpur (MY1)',	'Malaysian',	'458',	'ringgit (inv.)',	'MYR',	'sen (inv.)',	'RM',	2,	'Malaysia',	'142',	'035',	0,	'60',	'MY.png',	'2020-01-03 16:43:58',	'2020-01-03 16:43:58'),
(133,	'Maldives',	'MV',	'MDV',	'Malé',	'Maldivian',	'462',	'rufiyaa',	'MVR',	'laari (inv.)',	'Rf',	2,	'Republic of Maldives',	'142',	'034',	0,	'960',	'MV.png',	'2020-01-03 16:43:59',	'2020-01-03 16:43:59'),
(134,	'Mali',	'ML',	'MLI',	'Bamako',	'Malian',	'466',	'CFA franc (BCEAO)',	'XOF',	'centime',	'XOF',	0,	'Republic of Mali',	'002',	'011',	0,	'223',	'ML.png',	'2020-01-03 16:43:59',	'2020-01-03 16:43:59'),
(135,	'Malta',	'MT',	'MLT',	'Valletta',	'Maltese',	'470',	'euro',	'EUR',	'cent',	'MTL',	2,	'Republic of Malta',	'150',	'039',	1,	'356',	'MT.png',	'2020-01-03 16:43:59',	'2020-01-03 16:43:59'),
(136,	'Martinique',	'MQ',	'MTQ',	'Fort-de-France',	'Martinican',	'474',	'euro',	'EUR',	'cent',	'€',	2,	'Martinique',	'019',	'029',	0,	'596',	'MQ.png',	'2020-01-03 16:43:59',	'2020-01-03 16:43:59'),
(137,	'Mauritania',	'MR',	'MRT',	'Nouakchott',	'Mauritanian',	'478',	'ouguiya',	'MRO',	'khoum',	'UM',	2,	'Islamic Republic of Mauritania',	'002',	'011',	0,	'222',	'MR.png',	'2020-01-03 16:43:59',	'2020-01-03 16:43:59'),
(138,	'Mauritius',	'MU',	'MUS',	'Port Louis',	'Mauritian',	'480',	'Mauritian rupee',	'MUR',	'cent',	'₨',	2,	'Republic of Mauritius',	'002',	'014',	0,	'230',	'MU.png',	'2020-01-03 16:43:59',	'2020-01-03 16:43:59'),
(139,	'Mexico',	'MX',	'MEX',	'Mexico City',	'Mexican',	'484',	'Mexican peso',	'MXN',	'centavo',	'$',	2,	'United Mexican States',	'019',	'013',	0,	'52',	'MX.png',	'2020-01-03 16:43:59',	'2020-01-03 16:43:59'),
(140,	'Monaco',	'MC',	'MCO',	'Monaco',	'Monegasque',	'492',	'euro',	'EUR',	'cent',	'€',	2,	'Principality of Monaco',	'150',	'155',	0,	'377',	'MC.png',	'2020-01-03 16:44:00',	'2020-01-03 16:44:00'),
(141,	'Mongolia',	'MN',	'MNG',	'Ulan Bator',	'Mongolian',	'496',	'tugrik',	'MNT',	'möngö (inv.)',	'₮',	2,	'Mongolia',	'142',	'030',	0,	'976',	'MN.png',	'2020-01-03 16:44:00',	'2020-01-03 16:44:00'),
(142,	'Moldova, Republic of',	'MD',	'MDA',	'Chisinau',	'Moldovan',	'498',	'Moldovan leu (pl. lei)',	'MDL',	'ban',	'MDL',	2,	'Republic of Moldova',	'150',	'151',	0,	'373',	'MD.png',	'2020-01-03 16:44:00',	'2020-01-03 16:44:00'),
(143,	'Montenegro',	'ME',	'MNE',	'Podgorica',	'Montenegrin',	'499',	'euro',	'EUR',	'cent',	'€',	2,	'Montenegro',	'150',	'039',	0,	'382',	'ME.png',	'2020-01-03 16:44:00',	'2020-01-03 16:44:00'),
(144,	'Montserrat',	'MS',	'MSR',	'Plymouth (MS2)',	'Montserratian',	'500',	'East Caribbean dollar',	'XCD',	'cent',	'$',	2,	'Montserrat',	'019',	'029',	0,	'1',	'MS.png',	'2020-01-03 16:44:00',	'2020-01-03 16:44:00'),
(145,	'Morocco',	'MA',	'MAR',	'Rabat',	'Moroccan',	'504',	'Moroccan dirham',	'MAD',	'centime',	'MAD',	2,	'Kingdom of Morocco',	'002',	'015',	0,	'212',	'MA.png',	'2020-01-03 16:44:00',	'2020-01-03 16:44:00'),
(146,	'Mozambique',	'MZ',	'MOZ',	'Maputo',	'Mozambican',	'508',	'metical',	'MZN',	'centavo',	'MT',	2,	'Republic of Mozambique',	'002',	'014',	0,	'258',	'MZ.png',	'2020-01-03 16:44:00',	'2020-01-03 16:44:00'),
(147,	'Oman',	'OM',	'OMN',	'Muscat',	'Omani',	'512',	'Omani rial',	'OMR',	'baiza',	'﷼',	3,	'Sultanate of Oman',	'142',	'145',	0,	'968',	'OM.png',	'2020-01-03 16:44:01',	'2020-01-03 16:44:01'),
(148,	'Namibia',	'NA',	'NAM',	'Windhoek',	'Namibian',	'516',	'Namibian dollar',	'NAD',	'cent',	'$',	2,	'Republic of Namibia',	'002',	'018',	0,	'264',	'NA.png',	'2020-01-03 16:44:01',	'2020-01-03 16:44:01'),
(149,	'Nauru',	'NR',	'NRU',	'Yaren',	'Nauruan',	'520',	'Australian dollar',	'AUD',	'cent',	'$',	2,	'Republic of Nauru',	'009',	'057',	0,	'674',	'NR.png',	'2020-01-03 16:44:01',	'2020-01-03 16:44:01'),
(150,	'Nepal',	'NP',	'NPL',	'Kathmandu',	'Nepalese',	'524',	'Nepalese rupee',	'NPR',	'paisa (inv.)',	'₨',	2,	'Nepal',	'142',	'034',	0,	'977',	'NP.png',	'2020-01-03 16:44:01',	'2020-01-03 16:44:01'),
(151,	'Netherlands',	'NL',	'NLD',	'Amsterdam (NL2)',	'Dutch',	'528',	'euro',	'EUR',	'cent',	'€',	2,	'Kingdom of the Netherlands',	'150',	'155',	1,	'31',	'NL.png',	'2020-01-03 16:44:01',	'2020-01-03 16:44:01'),
(152,	'Curaçao',	'CW',	'CUW',	'Willemstad',	'Curaçaoan',	'531',	'Netherlands Antillean guilder (CW1)',	'ANG',	'cent',	NULL,	NULL,	'Curaçao',	'019',	'029',	0,	'599',	NULL,	'2020-01-03 16:44:01',	'2020-01-03 16:44:01'),
(153,	'Aruba',	'AW',	'ABW',	'Oranjestad',	'Aruban',	'533',	'Aruban guilder',	'AWG',	'cent',	'ƒ',	2,	'Aruba',	'019',	'029',	0,	'297',	'AW.png',	'2020-01-03 16:44:01',	'2020-01-03 16:44:01'),
(154,	'Sint Maarten (Dutch part)',	'SX',	'SXM',	'Philipsburg',	'Sint Maartener',	'534',	'Netherlands Antillean guilder (SX1)',	'ANG',	'cent',	NULL,	NULL,	'Sint Maarten',	'019',	'029',	0,	'721',	NULL,	'2020-01-03 16:44:01',	'2020-01-03 16:44:01'),
(155,	'Bonaire, Sint Eustatius and Saba',	'BQ',	'BES',	NULL,	'of Bonaire, Sint Eustatius and Saba',	'535',	'US dollar',	'USD',	'cent',	NULL,	NULL,	NULL,	'019',	'029',	0,	'599',	NULL,	'2020-01-03 16:44:02',	'2020-01-03 16:44:02'),
(156,	'New Caledonia',	'NC',	'NCL',	'Nouméa',	'New Caledonian',	'540',	'CFP franc',	'XPF',	'centime',	'XPF',	0,	'New Caledonia',	'009',	'054',	0,	'687',	'NC.png',	'2020-01-03 16:44:02',	'2020-01-03 16:44:02'),
(157,	'Vanuatu',	'VU',	'VUT',	'Port Vila',	'Vanuatuan',	'548',	'vatu (inv.)',	'VUV',	'',	'Vt',	0,	'Republic of Vanuatu',	'009',	'054',	0,	'678',	'VU.png',	'2020-01-03 16:44:02',	'2020-01-03 16:44:02'),
(158,	'New Zealand',	'NZ',	'NZL',	'Wellington',	'New Zealander',	'554',	'New Zealand dollar',	'NZD',	'cent',	'$',	2,	'New Zealand',	'009',	'053',	0,	'64',	'NZ.png',	'2020-01-03 16:44:02',	'2020-01-03 16:44:02'),
(159,	'Nicaragua',	'NI',	'NIC',	'Managua',	'Nicaraguan',	'558',	'córdoba oro',	'NIO',	'centavo',	'C$',	2,	'Republic of Nicaragua',	'019',	'013',	0,	'505',	'NI.png',	'2020-01-03 16:44:02',	'2020-01-03 16:44:02'),
(160,	'Niger',	'NE',	'NER',	'Niamey',	'Nigerien',	'562',	'CFA franc (BCEAO)',	'XOF',	'centime',	'XOF',	0,	'Republic of Niger',	'002',	'011',	0,	'227',	'NE.png',	'2020-01-03 16:44:02',	'2020-01-03 16:44:02'),
(161,	'Nigeria',	'NG',	'NGA',	'Abuja',	'Nigerian',	'566',	'naira (inv.)',	'NGN',	'kobo (inv.)',	'₦',	2,	'Federal Republic of Nigeria',	'002',	'011',	0,	'234',	'NG.png',	'2020-01-03 16:44:02',	'2020-01-03 16:44:02'),
(162,	'Niue',	'NU',	'NIU',	'Alofi',	'Niuean',	'570',	'New Zealand dollar',	'NZD',	'cent',	'$',	2,	'Niue',	'009',	'061',	0,	'683',	'NU.png',	'2020-01-03 16:44:02',	'2020-01-03 16:44:02'),
(163,	'Norfolk Island',	'NF',	'NFK',	'Kingston',	'Norfolk Islander',	'574',	'Australian dollar',	'AUD',	'cent',	'$',	2,	'Territory of Norfolk Island',	'009',	'053',	0,	'672',	'NF.png',	'2020-01-03 16:44:02',	'2020-01-03 16:44:02'),
(164,	'Norway',	'NO',	'NOR',	'Oslo',	'Norwegian',	'578',	'Norwegian krone (pl. kroner)',	'NOK',	'øre (inv.)',	'kr',	2,	'Kingdom of Norway',	'150',	'154',	0,	'47',	'NO.png',	'2020-01-03 16:44:02',	'2020-01-03 16:44:02'),
(165,	'Northern Mariana Islands',	'MP',	'MNP',	'Saipan',	'Northern Mariana Islander',	'580',	'US dollar',	'USD',	'cent',	'$',	2,	'Commonwealth of the Northern Mariana Islands',	'009',	'057',	0,	'1',	'MP.png',	'2020-01-03 16:44:02',	'2020-01-03 16:44:02'),
(166,	'United States Minor Outlying Islands',	'UM',	'UMI',	'United States Minor Outlying Islands',	'of United States Minor Outlying Islands',	'581',	'US dollar',	'USD',	'cent',	'$',	2,	'United States Minor Outlying Islands',	'',	'',	0,	'1',	'UM.png',	'2020-01-03 16:44:02',	'2020-01-03 16:44:02'),
(167,	'Micronesia, Federated States of',	'FM',	'FSM',	'Palikir',	'Micronesian',	'583',	'US dollar',	'USD',	'cent',	'$',	2,	'Federated States of Micronesia',	'009',	'057',	0,	'691',	'FM.png',	'2020-01-03 16:44:02',	'2020-01-03 16:44:02'),
(168,	'Marshall Islands',	'MH',	'MHL',	'Majuro',	'Marshallese',	'584',	'US dollar',	'USD',	'cent',	'$',	2,	'Republic of the Marshall Islands',	'009',	'057',	0,	'692',	'MH.png',	'2020-01-03 16:44:02',	'2020-01-03 16:44:02'),
(169,	'Palau',	'PW',	'PLW',	'Melekeok',	'Palauan',	'585',	'US dollar',	'USD',	'cent',	'$',	2,	'Republic of Palau',	'009',	'057',	0,	'680',	'PW.png',	'2020-01-03 16:44:03',	'2020-01-03 16:44:03'),
(170,	'Pakistan',	'PK',	'PAK',	'Islamabad',	'Pakistani',	'586',	'Pakistani rupee',	'PKR',	'paisa',	'₨',	2,	'Islamic Republic of Pakistan',	'142',	'034',	0,	'92',	'PK.png',	'2020-01-03 16:44:03',	'2020-01-03 16:44:03'),
(171,	'Panama',	'PA',	'PAN',	'Panama City',	'Panamanian',	'591',	'balboa',	'PAB',	'centésimo',	'B/.',	2,	'Republic of Panama',	'019',	'013',	0,	'507',	'PA.png',	'2020-01-03 16:44:03',	'2020-01-03 16:44:03'),
(172,	'Papua New Guinea',	'PG',	'PNG',	'Port Moresby',	'Papua New Guinean',	'598',	'kina (inv.)',	'PGK',	'toea (inv.)',	'PGK',	2,	'Independent State of Papua New Guinea',	'009',	'054',	0,	'675',	'PG.png',	'2020-01-03 16:44:03',	'2020-01-03 16:44:03'),
(173,	'Paraguay',	'PY',	'PRY',	'Asunción',	'Paraguayan',	'600',	'guaraní',	'PYG',	'céntimo',	'Gs',	0,	'Republic of Paraguay',	'019',	'005',	0,	'595',	'PY.png',	'2020-01-03 16:44:03',	'2020-01-03 16:44:03'),
(174,	'Peru',	'PE',	'PER',	'Lima',	'Peruvian',	'604',	'new sol',	'PEN',	'céntimo',	'S/.',	2,	'Republic of Peru',	'019',	'005',	0,	'51',	'PE.png',	'2020-01-03 16:44:03',	'2020-01-03 16:44:03'),
(175,	'Philippines',	'PH',	'PHL',	'Manila',	'Filipino',	'608',	'Philippine peso',	'PHP',	'centavo',	'Php',	2,	'Republic of the Philippines',	'142',	'035',	0,	'63',	'PH.png',	'2020-01-03 16:44:03',	'2020-01-03 16:44:03'),
(176,	'Pitcairn',	'PN',	'PCN',	'Adamstown',	'Pitcairner',	'612',	'New Zealand dollar',	'NZD',	'cent',	'$',	2,	'Pitcairn Islands',	'009',	'061',	0,	'649',	'PN.png',	'2020-01-03 16:44:03',	'2020-01-03 16:44:03'),
(177,	'Poland',	'PL',	'POL',	'Warsaw',	'Polish',	'616',	'zloty',	'PLN',	'grosz (pl. groszy)',	'zł',	2,	'Republic of Poland',	'150',	'151',	1,	'48',	'PL.png',	'2020-01-03 16:44:03',	'2020-01-03 16:44:03'),
(178,	'Portugal',	'PT',	'PRT',	'Lisbon',	'Portuguese',	'620',	'euro',	'EUR',	'cent',	'€',	2,	'Portuguese Republic',	'150',	'039',	1,	'351',	'PT.png',	'2020-01-03 16:44:03',	'2020-01-03 16:44:03'),
(179,	'Guinea-Bissau',	'GW',	'GNB',	'Bissau',	'Guinea-Bissau national',	'624',	'CFA franc (BCEAO)',	'XOF',	'centime',	'XOF',	0,	'Republic of Guinea-Bissau',	'002',	'011',	0,	'245',	'GW.png',	'2020-01-03 16:44:03',	'2020-01-03 16:44:03'),
(180,	'Timor-Leste',	'TL',	'TLS',	'Dili',	'East Timorese',	'626',	'US dollar',	'USD',	'cent',	'$',	2,	'Democratic Republic of East Timor',	'142',	'035',	0,	'670',	'TL.png',	'2020-01-03 16:44:03',	'2020-01-03 16:44:03'),
(181,	'Puerto Rico',	'PR',	'PRI',	'San Juan',	'Puerto Rican',	'630',	'US dollar',	'USD',	'cent',	'$',	2,	'Commonwealth of Puerto Rico',	'019',	'029',	0,	'1',	'PR.png',	'2020-01-03 16:44:03',	'2020-01-03 16:44:03'),
(182,	'Qatar',	'QA',	'QAT',	'Doha',	'Qatari',	'634',	'Qatari riyal',	'QAR',	'dirham',	'﷼',	2,	'State of Qatar',	'142',	'145',	0,	'974',	'QA.png',	'2020-01-03 16:44:03',	'2020-01-03 16:44:03'),
(183,	'Réunion',	'RE',	'REU',	'Saint-Denis',	'Reunionese',	'638',	'euro',	'EUR',	'cent',	'€',	2,	'Réunion',	'002',	'014',	0,	'262',	'RE.png',	'2020-01-03 16:44:04',	'2020-01-03 16:44:04'),
(184,	'Romania',	'RO',	'ROU',	'Bucharest',	'Romanian',	'642',	'Romanian leu (pl. lei)',	'RON',	'ban (pl. bani)',	'lei',	2,	'Romania',	'150',	'151',	1,	'40',	'RO.png',	'2020-01-03 16:44:04',	'2020-01-03 16:44:04'),
(185,	'Russian Federation',	'RU',	'RUS',	'Moscow',	'Russian',	'643',	'Russian rouble',	'RUB',	'kopek',	'руб',	2,	'Russian Federation',	'150',	'151',	0,	'7',	'RU.png',	'2020-01-03 16:44:04',	'2020-01-03 16:44:04'),
(186,	'Rwanda',	'RW',	'RWA',	'Kigali',	'Rwandan; Rwandese',	'646',	'Rwandese franc',	'RWF',	'centime',	'RWF',	0,	'Republic of Rwanda',	'002',	'014',	0,	'250',	'RW.png',	'2020-01-03 16:44:04',	'2020-01-03 16:44:04'),
(187,	'Saint Barthélemy',	'BL',	'BLM',	'Gustavia',	'of Saint Barthélemy',	'652',	'euro',	'EUR',	'cent',	NULL,	NULL,	'Collectivity of Saint Barthélemy',	'019',	'029',	0,	'590',	NULL,	'2020-01-03 16:44:04',	'2020-01-03 16:44:04'),
(188,	'Saint Helena, Ascension and Tristan da Cunha',	'SH',	'SHN',	'Jamestown',	'Saint Helenian',	'654',	'Saint Helena pound',	'SHP',	'penny',	'£',	2,	'Saint Helena, Ascension and Tristan da Cunha',	'002',	'011',	0,	'290',	'SH.png',	'2020-01-03 16:44:04',	'2020-01-03 16:44:04'),
(189,	'Saint Kitts and Nevis',	'KN',	'KNA',	'Basseterre',	'Kittsian; Nevisian',	'659',	'East Caribbean dollar',	'XCD',	'cent',	'$',	2,	'Federation of Saint Kitts and Nevis',	'019',	'029',	0,	'1',	'KN.png',	'2020-01-03 16:44:04',	'2020-01-03 16:44:04'),
(190,	'Anguilla',	'AI',	'AIA',	'The Valley',	'Anguillan',	'660',	'East Caribbean dollar',	'XCD',	'cent',	'$',	2,	'Anguilla',	'019',	'029',	0,	'1',	'AI.png',	'2020-01-03 16:44:04',	'2020-01-03 16:44:04'),
(191,	'Saint Lucia',	'LC',	'LCA',	'Castries',	'Saint Lucian',	'662',	'East Caribbean dollar',	'XCD',	'cent',	'$',	2,	'Saint Lucia',	'019',	'029',	0,	'1',	'LC.png',	'2020-01-03 16:44:04',	'2020-01-03 16:44:04'),
(192,	'Saint Martin (French part)',	'MF',	'MAF',	'Marigot',	'of Saint Martin',	'663',	'euro',	'EUR',	'cent',	NULL,	NULL,	'Collectivity of Saint Martin',	'019',	'029',	0,	'590',	NULL,	'2020-01-03 16:44:04',	'2020-01-03 16:44:04'),
(193,	'Saint Pierre and Miquelon',	'PM',	'SPM',	'Saint-Pierre',	'St-Pierrais; Miquelonnais',	'666',	'euro',	'EUR',	'cent',	'€',	2,	'Territorial Collectivity of Saint Pierre and Miquelon',	'019',	'021',	0,	'508',	'PM.png',	'2020-01-03 16:44:04',	'2020-01-03 16:44:04'),
(194,	'Saint Vincent and the Grenadines',	'VC',	'VCT',	'Kingstown',	'Vincentian',	'670',	'East Caribbean dollar',	'XCD',	'cent',	'$',	2,	'Saint Vincent and the Grenadines',	'019',	'029',	0,	'1',	'VC.png',	'2020-01-03 16:44:04',	'2020-01-03 16:44:04'),
(195,	'San Marino',	'SM',	'SMR',	'San Marino',	'San Marinese',	'674',	'euro',	'EUR',	'cent',	'€',	2,	'Republic of San Marino',	'150',	'039',	0,	'378',	'SM.png',	'2020-01-03 16:44:04',	'2020-01-03 16:44:04'),
(196,	'Sao Tome and Principe',	'ST',	'STP',	'São Tomé',	'São Toméan',	'678',	'dobra',	'STD',	'centavo',	'Db',	2,	'Democratic Republic of São Tomé and Príncipe',	'002',	'017',	0,	'239',	'ST.png',	'2020-01-03 16:44:04',	'2020-01-03 16:44:04'),
(197,	'Saudi Arabia',	'SA',	'SAU',	'Riyadh',	'Saudi Arabian',	'682',	'riyal',	'SAR',	'halala',	'﷼',	2,	'Kingdom of Saudi Arabia',	'142',	'145',	0,	'966',	'SA.png',	'2020-01-03 16:44:04',	'2020-01-03 16:44:04'),
(198,	'Senegal',	'SN',	'SEN',	'Dakar',	'Senegalese',	'686',	'CFA franc (BCEAO)',	'XOF',	'centime',	'XOF',	0,	'Republic of Senegal',	'002',	'011',	0,	'221',	'SN.png',	'2020-01-03 16:44:04',	'2020-01-03 16:44:04'),
(199,	'Serbia',	'RS',	'SRB',	'Belgrade',	'Serb',	'688',	'Serbian dinar',	'RSD',	'para (inv.)',	NULL,	NULL,	'Republic of Serbia',	'150',	'039',	0,	'381',	NULL,	'2020-01-03 16:44:05',	'2020-01-03 16:44:05'),
(200,	'Seychelles',	'SC',	'SYC',	'Victoria',	'Seychellois',	'690',	'Seychelles rupee',	'SCR',	'cent',	'₨',	2,	'Republic of Seychelles',	'002',	'014',	0,	'248',	'SC.png',	'2020-01-03 16:44:05',	'2020-01-03 16:44:05'),
(201,	'Sierra Leone',	'SL',	'SLE',	'Freetown',	'Sierra Leonean',	'694',	'leone',	'SLL',	'cent',	'Le',	2,	'Republic of Sierra Leone',	'002',	'011',	0,	'232',	'SL.png',	'2020-01-03 16:44:05',	'2020-01-03 16:44:05'),
(202,	'Singapore',	'SG',	'SGP',	'Singapore',	'Singaporean',	'702',	'Singapore dollar',	'SGD',	'cent',	'$',	2,	'Republic of Singapore',	'142',	'035',	0,	'65',	'SG.png',	'2020-01-03 16:44:05',	'2020-01-03 16:44:05'),
(203,	'Slovakia',	'SK',	'SVK',	'Bratislava',	'Slovak',	'703',	'euro',	'EUR',	'cent',	'Sk',	2,	'Slovak Republic',	'150',	'151',	1,	'421',	'SK.png',	'2020-01-03 16:44:05',	'2020-01-03 16:44:05'),
(204,	'Viet Nam',	'VN',	'VNM',	'Hanoi',	'Vietnamese',	'704',	'dong',	'VND',	'(10 hào',	'₫',	2,	'Socialist Republic of Vietnam',	'142',	'035',	0,	'84',	'VN.png',	'2020-01-03 16:44:05',	'2020-01-03 16:44:05'),
(205,	'Slovenia',	'SI',	'SVN',	'Ljubljana',	'Slovene',	'705',	'euro',	'EUR',	'cent',	'€',	2,	'Republic of Slovenia',	'150',	'039',	1,	'386',	'SI.png',	'2020-01-03 16:44:05',	'2020-01-03 16:44:05'),
(206,	'Somalia',	'SO',	'SOM',	'Mogadishu',	'Somali',	'706',	'Somali shilling',	'SOS',	'cent',	'S',	2,	'Somali Republic',	'002',	'014',	0,	'252',	'SO.png',	'2020-01-03 16:44:05',	'2020-01-03 16:44:05'),
(207,	'South Africa',	'ZA',	'ZAF',	'Pretoria (ZA1)',	'South African',	'710',	'rand',	'ZAR',	'cent',	'R',	2,	'Republic of South Africa',	'002',	'018',	0,	'27',	'ZA.png',	'2020-01-03 16:44:05',	'2020-01-03 16:44:05'),
(208,	'Zimbabwe',	'ZW',	'ZWE',	'Harare',	'Zimbabwean',	'716',	'Zimbabwe dollar (ZW1)',	'ZWL',	'cent',	'Z$',	2,	'Republic of Zimbabwe',	'002',	'014',	0,	'263',	'ZW.png',	'2020-01-03 16:44:05',	'2020-01-03 16:44:05'),
(209,	'Spain',	'ES',	'ESP',	'Madrid',	'Spaniard',	'724',	'euro',	'EUR',	'cent',	'€',	2,	'Kingdom of Spain',	'150',	'039',	1,	'34',	'ES.png',	'2020-01-03 16:44:05',	'2020-01-03 16:44:05'),
(210,	'South Sudan',	'SS',	'SSD',	'Juba',	'South Sudanese',	'728',	'South Sudanese pound',	'SSP',	'piaster',	NULL,	NULL,	'Republic of South Sudan',	'002',	'015',	0,	'211',	NULL,	'2020-01-03 16:44:05',	'2020-01-03 16:44:05'),
(211,	'Sudan',	'SD',	'SDN',	'Khartoum',	'Sudanese',	'729',	'Sudanese pound',	'SDG',	'piastre',	NULL,	NULL,	'Republic of the Sudan',	'002',	'015',	0,	'249',	NULL,	'2020-01-03 16:44:05',	'2020-01-03 16:44:05'),
(212,	'Western Sahara',	'EH',	'ESH',	'Al aaiun',	'Sahrawi',	'732',	'Moroccan dirham',	'MAD',	'centime',	'MAD',	2,	'Western Sahara',	'002',	'015',	0,	'212',	'EH.png',	'2020-01-03 16:44:05',	'2020-01-03 16:44:05'),
(213,	'Suriname',	'SR',	'SUR',	'Paramaribo',	'Surinamese',	'740',	'Surinamese dollar',	'SRD',	'cent',	'$',	2,	'Republic of Suriname',	'019',	'005',	0,	'597',	'SR.png',	'2020-01-03 16:44:06',	'2020-01-03 16:44:06'),
(214,	'Svalbard and Jan Mayen',	'SJ',	'SJM',	'Longyearbyen',	'of Svalbard',	'744',	'Norwegian krone (pl. kroner)',	'NOK',	'øre (inv.)',	'kr',	2,	'Svalbard and Jan Mayen',	'150',	'154',	0,	'47',	'SJ.png',	'2020-01-03 16:44:06',	'2020-01-03 16:44:06'),
(215,	'Swaziland',	'SZ',	'SWZ',	'Mbabane',	'Swazi',	'748',	'lilangeni',	'SZL',	'cent',	'SZL',	2,	'Kingdom of Swaziland',	'002',	'018',	0,	'268',	'SZ.png',	'2020-01-03 16:44:06',	'2020-01-03 16:44:06'),
(216,	'Sweden',	'SE',	'SWE',	'Stockholm',	'Swedish',	'752',	'krona (pl. kronor)',	'SEK',	'öre (inv.)',	'kr',	2,	'Kingdom of Sweden',	'150',	'154',	1,	'46',	'SE.png',	'2020-01-03 16:44:06',	'2020-01-03 16:44:06'),
(217,	'Switzerland',	'CH',	'CHE',	'Berne',	'Swiss',	'756',	'Swiss franc',	'CHF',	'centime',	'CHF',	2,	'Swiss Confederation',	'150',	'155',	0,	'41',	'CH.png',	'2020-01-03 16:44:06',	'2020-01-03 16:44:06'),
(218,	'Syrian Arab Republic',	'SY',	'SYR',	'Damascus',	'Syrian',	'760',	'Syrian pound',	'SYP',	'piastre',	'£',	2,	'Syrian Arab Republic',	'142',	'145',	0,	'963',	'SY.png',	'2020-01-03 16:44:06',	'2020-01-03 16:44:06'),
(219,	'Tajikistan',	'TJ',	'TJK',	'Dushanbe',	'Tajik',	'762',	'somoni',	'TJS',	'diram',	'TJS',	2,	'Republic of Tajikistan',	'142',	'143',	0,	'992',	'TJ.png',	'2020-01-03 16:44:06',	'2020-01-03 16:44:06'),
(220,	'Thailand',	'TH',	'THA',	'Bangkok',	'Thai',	'764',	'baht (inv.)',	'THB',	'satang (inv.)',	'฿',	2,	'Kingdom of Thailand',	'142',	'035',	0,	'66',	'TH.png',	'2020-01-03 16:44:06',	'2020-01-03 16:44:06'),
(221,	'Togo',	'TG',	'TGO',	'Lomé',	'Togolese',	'768',	'CFA franc (BCEAO)',	'XOF',	'centime',	'XOF',	0,	'Togolese Republic',	'002',	'011',	0,	'228',	'TG.png',	'2020-01-03 16:44:06',	'2020-01-03 16:44:06'),
(222,	'Tokelau',	'TK',	'TKL',	'(TK2)',	'Tokelauan',	'772',	'New Zealand dollar',	'NZD',	'cent',	'$',	2,	'Tokelau',	'009',	'061',	0,	'690',	'TK.png',	'2020-01-03 16:44:06',	'2020-01-03 16:44:06'),
(223,	'Tonga',	'TO',	'TON',	'Nuku’alofa',	'Tongan',	'776',	'pa’anga (inv.)',	'TOP',	'seniti (inv.)',	'T$',	2,	'Kingdom of Tonga',	'009',	'061',	0,	'676',	'TO.png',	'2020-01-03 16:44:06',	'2020-01-03 16:44:06'),
(224,	'Trinidad and Tobago',	'TT',	'TTO',	'Port of Spain',	'Trinidadian; Tobagonian',	'780',	'Trinidad and Tobago dollar',	'TTD',	'cent',	'TT$',	2,	'Republic of Trinidad and Tobago',	'019',	'029',	0,	'1',	'TT.png',	'2020-01-03 16:44:06',	'2020-01-03 16:44:06'),
(225,	'United Arab Emirates',	'AE',	'ARE',	'Abu Dhabi',	'Emirian',	'784',	'UAE dirham',	'AED',	'fils (inv.)',	'AED',	2,	'United Arab Emirates',	'142',	'145',	0,	'971',	'AE.png',	'2020-01-03 16:44:06',	'2020-01-03 16:44:06'),
(226,	'Tunisia',	'TN',	'TUN',	'Tunis',	'Tunisian',	'788',	'Tunisian dinar',	'TND',	'millime',	'TND',	3,	'Republic of Tunisia',	'002',	'015',	0,	'216',	'TN.png',	'2020-01-03 16:44:06',	'2020-01-03 16:44:06'),
(227,	'Turkey',	'TR',	'TUR',	'Ankara',	'Turk',	'792',	'Turkish lira (inv.)',	'TRY',	'kurus (inv.)',	'₺',	2,	'Republic of Turkey',	'142',	'145',	0,	'90',	'TR.png',	'2020-01-03 16:44:06',	'2020-01-03 16:44:06'),
(228,	'Turkmenistan',	'TM',	'TKM',	'Ashgabat',	'Turkmen',	'795',	'Turkmen manat (inv.)',	'TMT',	'tenge (inv.)',	'm',	2,	'Turkmenistan',	'142',	'143',	0,	'993',	'TM.png',	'2020-01-03 16:44:06',	'2020-01-03 16:44:06'),
(229,	'Turks and Caicos Islands',	'TC',	'TCA',	'Cockburn Town',	'Turks and Caicos Islander',	'796',	'US dollar',	'USD',	'cent',	'$',	2,	'Turks and Caicos Islands',	'019',	'029',	0,	'1',	'TC.png',	'2020-01-03 16:44:06',	'2020-01-03 16:44:06'),
(230,	'Tuvalu',	'TV',	'TUV',	'Funafuti',	'Tuvaluan',	'798',	'Australian dollar',	'AUD',	'cent',	'$',	2,	'Tuvalu',	'009',	'061',	0,	'688',	'TV.png',	'2020-01-03 16:44:07',	'2020-01-03 16:44:07'),
(231,	'Uganda',	'UG',	'UGA',	'Kampala',	'Ugandan',	'800',	'Uganda shilling',	'UGX',	'cent',	'UGX',	0,	'Republic of Uganda',	'002',	'014',	0,	'256',	'UG.png',	'2020-01-03 16:44:07',	'2020-01-03 16:44:07'),
(232,	'Ukraine',	'UA',	'UKR',	'Kiev',	'Ukrainian',	'804',	'hryvnia',	'UAH',	'kopiyka',	'₴',	2,	'Ukraine',	'150',	'151',	0,	'380',	'UA.png',	'2020-01-03 16:44:07',	'2020-01-03 16:44:07'),
(233,	'Macedonia, the former Yugoslav Republic of',	'MK',	'MKD',	'Skopje',	'of the former Yugoslav Republic of Macedonia',	'807',	'denar (pl. denars)',	'MKD',	'deni (inv.)',	'ден',	2,	'the former Yugoslav Republic of Macedonia',	'150',	'039',	0,	'389',	'MK.png',	'2020-01-03 16:44:07',	'2020-01-03 16:44:07'),
(234,	'Egypt',	'EG',	'EGY',	'Cairo',	'Egyptian',	'818',	'Egyptian pound',	'EGP',	'piastre',	'£',	2,	'Arab Republic of Egypt',	'002',	'015',	0,	'20',	'EG.png',	'2020-01-03 16:44:07',	'2020-01-03 16:44:07'),
(235,	'United Kingdom',	'GB',	'GBR',	'London',	'British',	'826',	'pound sterling',	'GBP',	'penny (pl. pence)',	'£',	2,	'United Kingdom of Great Britain and Northern Ireland',	'150',	'154',	1,	'44',	'GB.png',	'2020-01-03 16:44:07',	'2020-01-03 16:44:07'),
(236,	'Guernsey',	'GG',	'GGY',	'St Peter Port',	'of Guernsey',	'831',	'Guernsey pound (GG2)',	'GGP (GG2)',	'penny (pl. pence)',	NULL,	NULL,	'Bailiwick of Guernsey',	'150',	'154',	0,	'44',	NULL,	'2020-01-03 16:44:07',	'2020-01-03 16:44:07'),
(237,	'Jersey',	'JE',	'JEY',	'St Helier',	'of Jersey',	'832',	'Jersey pound (JE2)',	'JEP (JE2)',	'penny (pl. pence)',	NULL,	NULL,	'Bailiwick of Jersey',	'150',	'154',	0,	'44',	NULL,	'2020-01-03 16:44:07',	'2020-01-03 16:44:07'),
(238,	'Isle of Man',	'IM',	'IMN',	'Douglas',	'Manxman; Manxwoman',	'833',	'Manx pound (IM2)',	'IMP (IM2)',	'penny (pl. pence)',	NULL,	NULL,	'Isle of Man',	'150',	'154',	0,	'44',	NULL,	'2020-01-03 16:44:07',	'2020-01-03 16:44:07'),
(239,	'Tanzania, United Republic of',	'TZ',	'TZA',	'Dodoma (TZ1)',	'Tanzanian',	'834',	'Tanzanian shilling',	'TZS',	'cent',	'TZS',	2,	'United Republic of Tanzania',	'002',	'014',	0,	'255',	'TZ.png',	'2020-01-03 16:44:07',	'2020-01-03 16:44:07'),
(240,	'United States',	'US',	'USA',	'Washington DC',	'American',	'840',	'US dollar',	'USD',	'cent',	'$',	2,	'United States of America',	'019',	'021',	0,	'1',	'US.png',	'2020-01-03 16:44:07',	'2020-01-03 16:44:07'),
(241,	'Virgin Islands, U.S.',	'VI',	'VIR',	'Charlotte Amalie',	'US Virgin Islander',	'850',	'US dollar',	'USD',	'cent',	'$',	2,	'United States Virgin Islands',	'019',	'029',	0,	'1',	'VI.png',	'2020-01-03 16:44:07',	'2020-01-03 16:44:07'),
(242,	'Burkina Faso',	'BF',	'BFA',	'Ouagadougou',	'Burkinabe',	'854',	'CFA franc (BCEAO)',	'XOF',	'centime',	'XOF',	0,	'Burkina Faso',	'002',	'011',	0,	'226',	'BF.png',	'2020-01-03 16:44:07',	'2020-01-03 16:44:07'),
(243,	'Uruguay',	'UY',	'URY',	'Montevideo',	'Uruguayan',	'858',	'Uruguayan peso',	'UYU',	'centésimo',	'$U',	0,	'Eastern Republic of Uruguay',	'019',	'005',	0,	'598',	'UY.png',	'2020-01-03 16:44:07',	'2020-01-03 16:44:07'),
(244,	'Uzbekistan',	'UZ',	'UZB',	'Tashkent',	'Uzbek',	'860',	'sum (inv.)',	'UZS',	'tiyin (inv.)',	'лв',	2,	'Republic of Uzbekistan',	'142',	'143',	0,	'998',	'UZ.png',	'2020-01-03 16:44:07',	'2020-01-03 16:44:07'),
(245,	'Venezuela, Bolivarian Republic of',	'VE',	'VEN',	'Caracas',	'Venezuelan',	'862',	'bolívar fuerte (pl. bolívares fuertes)',	'VEF',	'céntimo',	'Bs',	2,	'Bolivarian Republic of Venezuela',	'019',	'005',	0,	'58',	'VE.png',	'2020-01-03 16:44:08',	'2020-01-03 16:44:08'),
(246,	'Wallis and Futuna',	'WF',	'WLF',	'Mata-Utu',	'Wallisian; Futunan; Wallis and Futuna Islander',	'876',	'CFP franc',	'XPF',	'centime',	'XPF',	0,	'Wallis and Futuna',	'009',	'061',	0,	'681',	'WF.png',	'2020-01-03 16:44:08',	'2020-01-03 16:44:08'),
(247,	'Samoa',	'WS',	'WSM',	'Apia',	'Samoan',	'882',	'tala (inv.)',	'WST',	'sene (inv.)',	'WS$',	2,	'Independent State of Samoa',	'009',	'061',	0,	'685',	'WS.png',	'2020-01-03 16:44:08',	'2020-01-03 16:44:08'),
(248,	'Yemen',	'YE',	'YEM',	'San’a',	'Yemenite',	'887',	'Yemeni rial',	'YER',	'fils (inv.)',	'﷼',	2,	'Republic of Yemen',	'142',	'145',	0,	'967',	'YE.png',	'2020-01-03 16:44:08',	'2020-01-03 16:44:08'),
(249,	'Zambia',	'ZM',	'ZMB',	'Lusaka',	'Zambian',	'894',	'Zambian kwacha (inv.)',	'ZMW',	'ngwee (inv.)',	'ZK',	2,	'Republic of Zambia',	'002',	'014',	0,	'260',	'ZM.png',	'2020-01-03 16:44:08',	'2020-01-03 16:44:08');

CREATE TABLE `customer` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(140) NOT NULL,
  `account_manager` int(11) DEFAULT NULL,
  `customer_type` varchar(140) NOT NULL,
  `bank_account` varchar(20) DEFAULT NULL,
  `billing_currency` char(3) DEFAULT 'KES',
  `default_rate_ref` int(11) DEFAULT NULL,
  `tax_ID` varchar(20) DEFAULT NULL,
  `customer_group` varchar(140) DEFAULT NULL,
  `sex` char(1) NOT NULL,
  `title_of_courtesy` char(3) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `mobile_phone` varchar(140) NOT NULL,
  `email_address` varchar(140) DEFAULT NULL,
  `ID_type` char(3) NOT NULL,
  `ID_no` varchar(8) NOT NULL,
  `ID_country` char(3) NOT NULL,
  `ID_attachment` varchar(140) DEFAULT NULL,
  `occupation` varchar(140) DEFAULT NULL,
  `first_billed` date DEFAULT NULL,
  `last_billed` date DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `credit_limit` decimal(10,0) DEFAULT '0',
  `is_internal_customer` tinyint(4) DEFAULT '0',
  `on_hold` tinyint(4) DEFAULT '0',
  `on_hold_from` date DEFAULT NULL,
  `on_hold_to` date DEFAULT NULL,
  `remarks` text,
  `fdesk_user` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `customer` (`id`, `customer_name`, `account_manager`, `customer_type`, `bank_account`, `billing_currency`, `default_rate_ref`, `tax_ID`, `customer_group`, `sex`, `title_of_courtesy`, `birth_date`, `mobile_phone`, `email_address`, `ID_type`, `ID_no`, `ID_country`, `ID_attachment`, `occupation`, `first_billed`, `last_billed`, `inactive`, `credit_limit`, `is_internal_customer`, `on_hold`, `on_hold_from`, `on_hold_to`, `remarks`, `fdesk_user`, `created_at`, `updated_at`) VALUES
(1,	'Abdirizack Bare',	0,	'Guest',	'',	NULL,	NULL,	'',	NULL,	'M',	'Mr.',	'0000-00-00',	'0711066100',	'zakibare@gmail.com',	'NI',	'24252435',	'KEN',	'',	'',	NULL,	NULL,	0,	NULL,	0,	NULL,	NULL,	NULL,	'',	1,	1581680955,	1583221621),
(2,	'Stephen Gituma',	0,	'Owner',	'',	'',	NULL,	'',	NULL,	'M',	'',	'0000-00-00',	'0729886600',	'',	'NI',	'10141025',	'KEN',	NULL,	'Engineer',	NULL,	NULL,	0,	NULL,	0,	NULL,	NULL,	NULL,	'',	1,	1581767582,	1582138998),
(3,	'Ken Mwai',	4,	'Tenant',	'',	NULL,	NULL,	'',	NULL,	'M',	'Mr.',	'1977-04-10',	'0732221498',	'mwaigichuhi@gmail.com',	'NI',	'14569198',	'KEN',	'uploads/kenmwai_gov.jpeg',	'Software Developer',	NULL,	NULL,	0,	NULL,	0,	NULL,	NULL,	NULL,	'',	1,	1582138529,	1583237905);

CREATE TABLE `department` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(140) NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `parent_id` int(11) DEFAULT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `department` (`id`, `code`, `name`, `enabled`, `parent_id`, `fdesk_user`, `created_at`, `updated_at`) VALUES
(1,	'HK',	'Housekeeping',	1,	2,	1,	1583843398,	1583848092),
(2,	'FM',	'Facility Management',	1,	NULL,	1,	1583848005,	1583848005);

CREATE TABLE `designation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(140) NOT NULL,
  `description` text,
  `enabled` tinyint(1) DEFAULT '1',
  `reports_to` int(11) DEFAULT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `designation` (`id`, `code`, `name`, `description`, `enabled`, `reports_to`, `fdesk_user`, `created_at`, `updated_at`) VALUES
(1,	'FM',	'Facility Manager',	'Oversees the maintenance and repair works on-premise units and utilities',	1,	2,	1,	1583844358,	1583847436),
(2,	'GM',	'General Manager',	'The overall operations manager',	1,	NULL,	1,	1583846516,	1583846516);

CREATE TABLE `email_settings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_address` varchar(255) NOT NULL,
  `from_name` varchar(255) DEFAULT NULL,
  `smtp_host` varchar(255) NOT NULL,
  `smtp_username` varchar(255) NOT NULL,
  `smtp_password` varchar(255) NOT NULL,
  `smtp_port` int(11) NOT NULL,
  `smtp_starttls` tinyint(1) DEFAULT NULL,
  `smtp_timeout` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `email_settings` (`id`, `from_address`, `from_name`, `smtp_host`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_starttls`, `smtp_timeout`, `created_at`, `updated_at`) VALUES
(1,	'support@logicent.co',	'Support @ Logicent',	'smtp.sparkpostmail.com',	'SMTP_Injection',	'2ff9363bc2e9395166b5b276e83aef57d6eb91e4',	587,	1,	0,	1581063648,	1582798038);

CREATE TABLE `email_templates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `heading` text NOT NULL,
  `content` text NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `employee` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `employee_name` varchar(140) NOT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `employee_type` varchar(140) NOT NULL,
  `bank_account` varchar(20) DEFAULT NULL,
  `base_salary` decimal(10,2) DEFAULT NULL,
  `tax_ID` varchar(20) DEFAULT NULL,
  `employee_group` varchar(140) DEFAULT NULL,
  `sex` char(1) NOT NULL,
  `title_of_courtesy` char(3) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `mobile_phone` varchar(140) NOT NULL,
  `email_address` varchar(140) DEFAULT NULL,
  `ID_type` char(3) NOT NULL,
  `ID_no` varchar(8) NOT NULL,
  `ID_country` char(3) NOT NULL,
  `ID_attachment` varchar(140) DEFAULT NULL,
  `occupation` varchar(140) DEFAULT NULL,
  `date_joined` date DEFAULT NULL,
  `date_left` date DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `on_hold` tinyint(4) DEFAULT '0',
  `on_hold_from` date DEFAULT NULL,
  `on_hold_to` date DEFAULT NULL,
  `remarks` text,
  `fdesk_user` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `employee_attendance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `work_day` date NOT NULL,
  `status` varchar(255) NOT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `employment_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `description` varchar(140) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `fdesk_user` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `employment_type` (`id`, `code`, `description`, `enabled`, `fdesk_user`, `created_at`, `updated_at`) VALUES
(1,	'INT',	'Intern',	1,	1,	1583855492,	1583855492),
(2,	'FT',	'Full-time',	1,	1,	1583855611,	1583855611),
(3,	'PT',	'Part-time',	1,	1,	1583855620,	1583855620),
(4,	'CON',	'Contract',	1,	1,	1583855658,	1583855658);

CREATE TABLE `expense` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `reference` int(11) NOT NULL,
  `date` date NOT NULL,
  `payee` varchar(50) NOT NULL,
  `gl_account_id` int(11) DEFAULT NULL,
  `amount` decimal(10,0) NOT NULL,
  `tax_id` int(11) DEFAULT NULL,
  `bank_account_id` int(11) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `expense` (`id`, `reference`, `date`, `payee`, `gl_account_id`, `amount`, `tax_id`, `bank_account_id`, `description`, `fdesk_user`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	1001,	'2020-02-07',	'Mdee',	NULL,	50,	NULL,	NULL,	'Sabuni',	1,	'2020-02-07 16:09:34',	'2020-02-07 16:12:01',	'2020-02-07 16:12:01');

CREATE TABLE `expense_claim` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `reference` int(11) NOT NULL,
  `date` date NOT NULL,
  `payer` varchar(255) DEFAULT NULL,
  `payee` varchar(255) NOT NULL,
  `gl_account_id` int(11) DEFAULT NULL,
  `credit_account_id` int(11) DEFAULT NULL,
  `amount` decimal(10,0) NOT NULL,
  `tax_id` int(11) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `facility_amenities` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(140) NOT NULL,
  `enabled` tinyint(1) DEFAULT '0',
  `fdesk_user` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `facility_amenities` (`id`, `code`, `name`, `enabled`, `fdesk_user`, `created_at`, `updated_at`) VALUES
(1,	'DSTV',	'DSTV complimentary channels are available in all rooms',	1,	0,	1581579131,	1582027188),
(2,	'FREE Internet',	'Free wireless Internet access 24 hours a day',	1,	1,	1581586442,	1581586638),
(3,	'AirCon',	'Air-conditioned rooms',	1,	1,	1582803129,	1582803129),
(4,	'Ceil-Fan',	'Ceiling fan for cooling the room',	0,	1,	1582803163,	1582803170);

CREATE TABLE `facility_booking` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `reg_no` int(11) NOT NULL,
  `folio_no` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `fdesk_user` int(11) NOT NULL,
  `res_no` int(11) DEFAULT NULL,
  `status` char(3) NOT NULL,
  `checkin` datetime NOT NULL,
  `checkout` datetime NOT NULL,
  `duration` int(4) NOT NULL DEFAULT '1',
  `pax_adults` int(3) NOT NULL DEFAULT '1',
  `pax_children` int(3) NOT NULL DEFAULT '0',
  `pax_infants` int(3) NOT NULL DEFAULT '0',
  `voucher_no` int(11) DEFAULT NULL,
  `sex` char(1) NOT NULL,
  `customer_name` varchar(140) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `country` char(3) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `payment_type` varchar(20) DEFAULT NULL,
  `verify_code` varchar(20) DEFAULT NULL,
  `card_type` varchar(20) DEFAULT NULL,
  `card_no` varchar(20) DEFAULT NULL,
  `card_expire` date DEFAULT NULL,
  `rate_type` int(4) NOT NULL,
  `rate_amount` double NOT NULL DEFAULT '0',
  `vat_amount` double NOT NULL DEFAULT '0',
  `total_amount` double NOT NULL DEFAULT '0',
  `total_charge` double NOT NULL DEFAULT '0',
  `total_payment` double NOT NULL DEFAULT '0',
  `id_type` char(3) NOT NULL,
  `id_number` varchar(20) NOT NULL,
  `id_country` char(3) NOT NULL,
  `remarks` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `facility_booking` (`id`, `reg_no`, `folio_no`, `customer_id`, `unit_id`, `fdesk_user`, `res_no`, `status`, `checkin`, `checkout`, `duration`, `pax_adults`, `pax_children`, `pax_infants`, `voucher_no`, `sex`, `customer_name`, `address`, `city`, `country`, `email`, `phone`, `payment_type`, `verify_code`, `card_type`, `card_no`, `card_expire`, `rate_type`, `rate_amount`, `vat_amount`, `total_amount`, `total_charge`, `total_payment`, `id_type`, `id_number`, `id_country`, `remarks`, `created_at`, `updated_at`, `deleted_at`) VALUES
(3,	1001,	0,	1,	4,	1,	0,	'CI',	'2020-02-28 19:37:00',	'2020-02-29 10:00:00',	1,	1,	0,	0,	0,	'M',	'',	'',	NULL,	NULL,	'abdibare@gmail.com',	'0891660611',	NULL,	NULL,	NULL,	NULL,	NULL,	2,	4800,	0,	4800,	0,	4800,	'NI',	'21901209',	'KEN',	'',	'2020-02-28 19:48:20',	'2020-02-28 19:48:20',	NULL);

CREATE TABLE `facility_reservation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `res_no` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `fdesk_user` int(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  `checkin` datetime NOT NULL,
  `checkout` datetime NOT NULL,
  `duration` int(4) NOT NULL,
  `pax_adults` int(3) NOT NULL DEFAULT '1',
  `pax_children` int(3) NOT NULL DEFAULT '0',
  `pax_infants` int(3) NOT NULL DEFAULT '0',
  `voucher_no` int(11) DEFAULT NULL,
  `customer_name` varchar(140) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `country` char(3) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `rate_type` int(4) NOT NULL,
  `id_type` char(3) DEFAULT NULL,
  `id_number` varchar(20) DEFAULT NULL,
  `id_country` char(3) DEFAULT NULL,
  `remarks` text,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `facility_reservation` (`id`, `res_no`, `customer_id`, `unit_id`, `fdesk_user`, `status`, `checkin`, `checkout`, `duration`, `pax_adults`, `pax_children`, `pax_infants`, `voucher_no`, `customer_name`, `address`, `city`, `country`, `email`, `phone`, `rate_type`, `id_type`, `id_number`, `id_country`, `remarks`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	1,	1,	3,	1,	'CI',	'2020-02-25 04:13:00',	'2020-02-26 00:00:00',	1,	1,	0,	0,	0,	NULL,	'',	NULL,	NULL,	'',	'+254 711 066016',	2,	'NI',	'',	'KEN',	'',	'2020-02-25',	'2020-02-25',	NULL);

CREATE TABLE `fd_booking` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `reg_no` int(11) NOT NULL,
  `folio_no` int(11) DEFAULT NULL,
  `room_id` int(11) NOT NULL,
  `fdesk_user` int(11) NOT NULL,
  `res_no` int(11) DEFAULT NULL,
  `status` char(3) NOT NULL,
  `checkin` datetime NOT NULL,
  `checkout` datetime DEFAULT NULL,
  `duration` int(4) DEFAULT '1',
  `pax_adults` int(3) DEFAULT '1',
  `pax_children` int(3) DEFAULT '0',
  `voucher_no` int(11) DEFAULT NULL,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `sex` char(1) NOT NULL,
  `address` varchar(150) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `payment_type` varchar(20) DEFAULT NULL,
  `verify_code` varchar(20) DEFAULT NULL,
  `card_type` varchar(20) DEFAULT NULL,
  `card_no` varchar(20) DEFAULT NULL,
  `card_expire` date DEFAULT NULL,
  `rate_type` int(4) NOT NULL,
  `rate_amount` double NOT NULL DEFAULT '0',
  `vat_amount` double NOT NULL DEFAULT '0',
  `total_amount` double NOT NULL DEFAULT '0',
  `total_charge` double NOT NULL DEFAULT '0',
  `total_payment` double NOT NULL DEFAULT '0',
  `id_type` char(3) DEFAULT NULL,
  `id_number` varchar(20) DEFAULT NULL,
  `id_country` int(11) DEFAULT NULL,
  `remarks` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `fd_booking` (`id`, `reg_no`, `folio_no`, `room_id`, `fdesk_user`, `res_no`, `status`, `checkin`, `checkout`, `duration`, `pax_adults`, `pax_children`, `voucher_no`, `last_name`, `first_name`, `sex`, `address`, `city`, `country`, `email`, `phone`, `payment_type`, `verify_code`, `card_type`, `card_no`, `card_expire`, `rate_type`, `rate_amount`, `vat_amount`, `total_amount`, `total_charge`, `total_payment`, `id_type`, `id_number`, `id_country`, `remarks`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	1001,	0,	29,	1,	0,	'CO',	'2020-01-24 16:40:00',	'2020-01-25 10:00:00',	1,	1,	0,	0,	'Mwai',	'Ken',	'M',	'',	NULL,	NULL,	'',	'0712822662',	NULL,	NULL,	NULL,	NULL,	NULL,	2,	2000,	0,	2000,	0,	2000,	'NI',	'14569198',	110,	'',	'2020-01-24 16:44:42',	'2020-02-01 15:27:33',	NULL),
(5,	1002,	0,	14,	1,	0,	'CO',	'2020-01-24 19:42:00',	'2020-01-25 10:00:00',	1,	1,	0,	0,	'Kim',	'Dan',	'M',	'',	NULL,	NULL,	'dkimani@logicent.co',	'0724805036',	NULL,	NULL,	NULL,	NULL,	NULL,	3,	2500,	0,	2500,	0,	2500,	'NI',	'23445678',	110,	'',	'2020-01-24 20:05:50',	'2020-02-06 11:35:16',	NULL),
(6,	1003,	1002,	7,	1,	0,	'CI',	'2020-01-24 00:00:00',	'2020-01-25 10:00:00',	1,	1,	0,	0,	'Kilobi',	'Mary',	'F',	'',	NULL,	NULL,	'',	'0723156661',	NULL,	NULL,	NULL,	NULL,	NULL,	3,	2500,	0,	2500,	0,	2500,	'NI',	'21908980',	110,	'',	'2020-01-24 21:14:29',	'2020-02-06 11:35:22',	NULL);

CREATE TABLE `fd_reservation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `res_no` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `fdesk_user` int(11) NOT NULL,
  `status` varchar(6) NOT NULL,
  `checkin` datetime NOT NULL,
  `checkout` datetime NOT NULL,
  `duration` int(4) NOT NULL,
  `pax_adults` int(3) NOT NULL,
  `pax_children` int(3) NOT NULL,
  `voucher_no` int(11) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `address` varchar(150) NOT NULL,
  `city` varchar(20) NOT NULL,
  `country` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `rate_type` int(4) NOT NULL,
  `id_type` char(3) NOT NULL,
  `id_number` varchar(20) NOT NULL,
  `id_country` int(11) NOT NULL,
  `remarks` text NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `gift_vouchers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(140) NOT NULL,
  `name` varchar(140) NOT NULL,
  `type` varchar(140) NOT NULL,
  `valid_from` date DEFAULT NULL,
  `valid_to` date DEFAULT NULL,
  `value` decimal(10,2) NOT NULL,
  `is_redeemed` tinyint(1) NOT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `inventory_item` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `buy_price` decimal(10,4) DEFAULT NULL COMMENT 'Purchase price',
  `sell_price` decimal(10,4) DEFAULT NULL COMMENT 'Sale price',
  `qty` decimal(10,4) DEFAULT NULL,
  `unit_price` decimal(10,4) DEFAULT NULL,
  `has_OB` tinyint(1) DEFAULT NULL,
  `OB_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `invoice_template` (
  `id` int(11) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `num_prefix` char(3) DEFAULT NULL,
  `terms_pmt_advice` varchar(255) DEFAULT NULL COMMENT 'Terms & payment advice',
  `footer` varchar(255) DEFAULT NULL,
  `amounts_tax_inc` tinyint(1) DEFAULT NULL COMMENT 'Amounts are tax inclusive',
  `enable_pmt_advice_ca` tinyint(1) DEFAULT NULL COMMENT 'Enable payment advice cut-away',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `Item` (
  `owner` varchar(0) DEFAULT NULL,
  `modifiedBy` varchar(0) DEFAULT NULL,
  `creation` varchar(0) DEFAULT NULL,
  `modified` varchar(0) DEFAULT NULL,
  `keywords` varchar(0) DEFAULT NULL,
  `name` varchar(0) DEFAULT NULL,
  `image` varchar(0) DEFAULT NULL,
  `description` varchar(0) DEFAULT NULL,
  `unit` varchar(0) DEFAULT NULL,
  `itemType` varchar(0) DEFAULT NULL,
  `incomeAccount` varchar(0) DEFAULT NULL,
  `expenseAccount` varchar(0) DEFAULT NULL,
  `tax` varchar(0) DEFAULT NULL,
  `rate` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE `leases` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `date_leased` date NOT NULL,
  `premise_use` varchar(255) NOT NULL,
  `lease_period` int(11) NOT NULL,
  `billed_period` varchar(255) NOT NULL,
  `billed_amount` decimal(10,2) NOT NULL,
  `require_deposit` tinyint(1) NOT NULL,
  `deposit_amount` decimal(10,2) NOT NULL,
  `deposit_includes` text,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `owner_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `attachments` text,
  `on_hold` tinyint(1) DEFAULT NULL,
  `on_hold_from` date DEFAULT NULL,
  `on_hold_to` date DEFAULT NULL,
  `remarks` text,
  `fdesk_user` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `leases` (`id`, `reference`, `title`, `customer_id`, `status`, `date_leased`, `premise_use`, `lease_period`, `billed_period`, `billed_amount`, `require_deposit`, `deposit_amount`, `deposit_includes`, `start_date`, `end_date`, `owner_id`, `property_id`, `unit_id`, `attachments`, `on_hold`, `on_hold_from`, `on_hold_to`, `remarks`, `fdesk_user`, `created_at`, `updated_at`) VALUES
(1,	'ORT/32-306',	'Music Studio & IT Office',	3,	'',	'2019-10-22',	'Teaching music lessons and developing IT projects',	60,	'M',	17000.00,	0,	36500.00,	'Office and elec meter deposit',	'2019-11-01',	'2024-11-01',	2,	1,	10,	'',	0,	'0000-00-00',	'0000-00-00',	'',	1,	1582139981,	1582746325);

CREATE TABLE `letter_templates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `heading` text NOT NULL,
  `content` text NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `migration` (
  `type` varchar(25) NOT NULL,
  `name` varchar(50) NOT NULL,
  `migration` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `migration` (`type`, `name`, `migration`) VALUES
('package',	'auth',	'001_auth_create_usertables'),
('package',	'auth',	'002_auth_create_grouptables'),
('package',	'auth',	'003_auth_create_roletables'),
('package',	'auth',	'004_auth_create_permissiontables'),
('package',	'auth',	'005_auth_create_authdefaults'),
('package',	'auth',	'006_auth_add_authactions'),
('package',	'auth',	'007_auth_add_permissionsfilter'),
('package',	'auth',	'008_auth_create_providers'),
('package',	'auth',	'009_auth_create_oauth2tables'),
('package',	'auth',	'010_auth_fix_jointables'),
('package',	'auth',	'011_auth_group_optional'),
('app',	'default',	'001_create_facility_booking'),
('app',	'default',	'002_create_room_type'),
('app',	'default',	'003_create_room'),
('app',	'default',	'004_create_rate'),
('app',	'default',	'005_create_sales_payment'),
('app',	'default',	'006_create_sales_invoice'),
('app',	'default',	'007_create_sales_invoice_item'),
('app',	'default',	'008_create_expense_claim'),
('app',	'default',	'009_create_countries'),
('app',	'default',	'010_create_rate_type'),
('package',	'auth',	'001_auth_create_usertables'),
('package',	'auth',	'002_auth_create_grouptables'),
('package',	'auth',	'003_auth_create_roletables'),
('package',	'auth',	'004_auth_create_permissiontables'),
('package',	'auth',	'005_auth_create_authdefaults'),
('package',	'auth',	'006_auth_add_authactions'),
('package',	'auth',	'007_auth_add_permissionsfilter'),
('package',	'auth',	'008_auth_create_providers'),
('package',	'auth',	'009_auth_create_oauth2tables'),
('package',	'auth',	'010_auth_fix_jointables'),
('package',	'auth',	'011_auth_group_optional'),
('app',	'default',	'001_create_facility_booking'),
('app',	'default',	'002_create_room_type'),
('app',	'default',	'003_create_room'),
('app',	'default',	'004_create_rate'),
('app',	'default',	'005_create_sales_payment'),
('app',	'default',	'006_create_sales_invoice'),
('app',	'default',	'007_create_sales_invoice_item'),
('app',	'default',	'008_create_expense_claim'),
('app',	'default',	'009_create_countries'),
('app',	'default',	'010_create_rate_type'),
('app',	'default',	'011_create_business'),
('app',	'default',	'012_create_facility_reservation'),
('app',	'default',	'013_create_service_item'),
('app',	'default',	'014_create_report'),
('app',	'default',	'015_create_report_period'),
('app',	'default',	'016_add_deleted_at_to_users'),
('app',	'default',	'017_add_sex_to_facility_booking'),
('app',	'default',	'018_create_bank_account'),
('app',	'default',	'019_create_bank_deposit'),
('app',	'default',	'020_create_expense'),
('app',	'default',	'021_create_summary'),
('app',	'default',	'022_create_email_settings'),
('app',	'default',	'023_create_taxes'),
('app',	'default',	'024_create_payment_methods'),
('app',	'default',	'025_create_facility_amenities'),
('app',	'default',	'026_create_email_templates'),
('app',	'default',	'027_create_customer'),
('app',	'default',	'028_create_service_types'),
('app',	'default',	'029_create_partners'),
('app',	'default',	'030_create_gift_vouchers'),
('app',	'default',	'031_create_properties'),
('app',	'default',	'032_create_unit_type'),
('app',	'default',	'033_create_unit'),
('app',	'default',	'034_create_property_settings'),
('app',	'default',	'035_create_leases'),
('app',	'default',	'036_create_property_types'),
('app',	'default',	'037_create_employee'),
('app',	'default',	'038_create_employment_type'),
('app',	'default',	'039_create_department'),
('app',	'default',	'040_create_designation'),
('app',	'default',	'041_create_salary_component'),
('app',	'default',	'042_create_salary_slip'),
('app',	'default',	'043_create_employee_attendance');

CREATE TABLE `modules` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `visible` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `partners` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `partner_name` varchar(140) NOT NULL,
  `account_manager` int(11) DEFAULT NULL,
  `partner_type` varchar(140) NOT NULL,
  `bank_account` varchar(20) DEFAULT NULL,
  `billing_currency` char(3) DEFAULT 'KES',
  `default_rate_ref` int(11) DEFAULT NULL,
  `tax_ID` varchar(20) DEFAULT NULL,
  `partner_group` varchar(140) NOT NULL,
  `phone` varchar(140) NOT NULL,
  `email_address` varchar(140) DEFAULT NULL,
  `first_billed` date DEFAULT NULL,
  `last_billed` date DEFAULT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `credit_limit` decimal(10,0) DEFAULT '0',
  `on_hold` tinyint(4) DEFAULT '0',
  `on_hold_from` date DEFAULT NULL,
  `on_hold_to` date DEFAULT NULL,
  `remarks` text,
  `fdesk_user` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `partners` (`id`, `partner_name`, `account_manager`, `partner_type`, `bank_account`, `billing_currency`, `default_rate_ref`, `tax_ID`, `partner_group`, `phone`, `email_address`, `first_billed`, `last_billed`, `inactive`, `credit_limit`, `on_hold`, `on_hold_from`, `on_hold_to`, `remarks`, `fdesk_user`, `created_at`, `updated_at`) VALUES
(1,	'Glory Car Hire',	0,	'BS',	NULL,	NULL,	NULL,	'',	'Local',	'020-234 4564',	'info@glorycarhire.co.ke',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	1581577931,	1581577931),
(3,	'Logicent',	0,	'Co',	NULL,	NULL,	NULL,	'A0345890W',	'Local',	'0712822662',	'mwai@logicent.co',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	1581676325,	1581939132);

CREATE TABLE `payment_methods` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(140) NOT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `payment_methods` (`id`, `code`, `name`, `is_default`, `enabled`, `fdesk_user`, `created_at`, `updated_at`) VALUES
(1,	'CASH',	'Cash',	1,	1,	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(2,	'MPesa',	'M-Pesa',	0,	1,	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(3,	'CHQ',	'Cheque',	0,	0,	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(4,	'CCard',	'Credit Card',	0,	1,	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(5,	'DCard',	'Debit Card',	0,	1,	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00'),
(6,	'GVcr',	'Gift Voucher',	0,	0,	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00');

CREATE TABLE `policy_templates` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `heading` text NOT NULL,
  `content` text NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `properties` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) DEFAULT NULL,
  `name` varchar(140) NOT NULL,
  `description` varchar(140) DEFAULT NULL,
  `physical_address` varchar(140) DEFAULT NULL,
  `map_location` varchar(140) DEFAULT NULL,
  `property_type` varchar(20) NOT NULL,
  `owner` int(11) DEFAULT NULL,
  `ID_attachment` varchar(140) DEFAULT NULL,
  `property_ref` varchar(140) NOT NULL,
  `date_signed` date DEFAULT NULL,
  `date_released` date DEFAULT NULL,
  `inactive` tinyint(1) DEFAULT '0',
  `on_hold` tinyint(1) DEFAULT NULL,
  `on_hold_from` date DEFAULT NULL,
  `on_hold_to` date DEFAULT NULL,
  `remarks` text,
  `fdesk_user` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `properties` (`id`, `code`, `name`, `description`, `physical_address`, `map_location`, `property_type`, `owner`, `ID_attachment`, `property_ref`, `date_signed`, `date_released`, `inactive`, `on_hold`, `on_hold_from`, `on_hold_to`, `remarks`, `fdesk_user`, `created_at`, `updated_at`) VALUES
(1,	'CBP',	'Crystal Business Plaza',	'Retail and Office leasing space.',	'Off Magadi Road, Ongata Rongai Township',	'',	'COM',	2,	NULL,	'',	'2010-01-03',	'0000-00-00',	0,	NULL,	NULL,	NULL,	'',	0,	1581685531,	1582804559),
(2,	'MA',	'Mwalimu Apartments',	'2-bedroom and 1-bedroom housing apartments',	'Off Magadi Road from Naivas Supermarket, Ongata Rongai Township',	'',	'RES',	0,	NULL,	'',	'0000-00-00',	'0000-00-00',	0,	NULL,	NULL,	NULL,	'',	1,	1582027049,	1582114594),
(3,	'SPH',	'Suhufi Palace Hotel',	'The picturesque Suhufi Palace Hotel in Mombasa is situated in the heart of Mombasa Island',	'Abdul Nassir Road Bondeni, Mombasa.',	'',	'H/CH',	0,	NULL,	'',	'0000-00-00',	'0000-00-00',	0,	NULL,	NULL,	NULL,	'',	1,	1582050623,	1582114571),
(4,	'NSC',	'Nyali Sports Club',	'',	'Nyali, Mombasa',	'',	'G/S',	0,	NULL,	'',	'0000-00-00',	'0000-00-00',	1,	NULL,	NULL,	NULL,	'',	1,	1582050689,	1582114605),
(5,	'SP',	'Siron Place',	'',	'Along Magadi Rd., Ongata Rongai',	'',	'MU/MP',	0,	NULL,	'',	'0000-00-00',	'0000-00-00',	0,	NULL,	NULL,	NULL,	'',	1,	1582050733,	1582114583),
(6,	'TS',	'The Smith',	'',	'',	'',	'B/I/L',	0,	NULL,	'',	'0000-00-00',	'0000-00-00',	0,	NULL,	NULL,	NULL,	'',	1,	1582050765,	1582114549);

CREATE TABLE `property_settings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `property_id` int(11) NOT NULL,
  `key` varchar(140) NOT NULL,
  `value` varchar(140) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `property_types` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(140) NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `fdesk_user` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `property_types` (`id`, `code`, `name`, `enabled`, `fdesk_user`, `created_at`, `updated_at`) VALUES
(1,	'H/CH',	'Hotel / City Hotel',	1,	1,	1582804104,	1582804104),
(2,	'B/I/L',	'BnB / Inn / Lodge',	1,	1,	1582985372,	1582985372),
(3,	'HSTL',	'Hostel',	1,	1,	1582985435,	1582985435),
(4,	'RSRT',	'Resort',	1,	1,	1582985451,	1582985451),
(5,	'G/S',	'Gym / Spa',	1,	1,	1582985468,	1582985468),
(6,	'RES',	'Residential',	1,	1,	1582985512,	1582985512),
(7,	'COM',	'Commercial',	1,	1,	1582985524,	1582985524),
(8,	'SA',	'Serviced Apartments',	1,	1,	1582985540,	1582985540),
(9,	'MU/MP',	'Mixed Use / Multi-property',	1,	1,	1582985569,	1582985569),
(10,	'IND',	'Industrial',	1,	1,	1584301918,	1584301918);

CREATE TABLE `rate` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rate_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `description` text,
  `amount` decimal(10,0) DEFAULT '0',
  `charges` decimal(10,0) NOT NULL DEFAULT '0',
  `billing_period` varchar(140) DEFAULT NULL,
  `is_tax_incl` tinyint(1) DEFAULT '0',
  `enabled` tinyint(1) DEFAULT '1',
  `rate_group` varchar(140) DEFAULT NULL,
  `applicable_tax` text,
  `channels` text,
  `valid_from` date DEFAULT NULL,
  `valid_until` date DEFAULT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `rate` (`id`, `rate_id`, `type_id`, `description`, `amount`, `charges`, `billing_period`, `is_tax_incl`, `enabled`, `rate_group`, `applicable_tax`, `channels`, `valid_from`, `valid_until`, `fdesk_user`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	1,	1,	'',	0,	4300,	NULL,	0,	1,	'',	NULL,	NULL,	NULL,	NULL,	0,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL),
(2,	1,	2,	'',	0,	4800,	NULL,	0,	1,	'',	NULL,	NULL,	NULL,	NULL,	0,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL),
(3,	1,	3,	'',	0,	3800,	NULL,	0,	1,	'',	NULL,	NULL,	NULL,	NULL,	0,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL),
(4,	1,	4,	'',	0,	3800,	NULL,	NULL,	0,	'',	NULL,	NULL,	NULL,	NULL,	0,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL),
(5,	1,	5,	'',	0,	3200,	NULL,	0,	1,	'',	NULL,	NULL,	NULL,	NULL,	0,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL);

CREATE TABLE `rate_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(140) NOT NULL,
  `description` text,
  `enabled` tinyint(1) DEFAULT '1',
  `fdesk_user` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `rate_type` (`id`, `name`, `description`, `enabled`, `fdesk_user`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'Bed and Breakfast',	'Accommodation includes breakfast meal only',	1,	NULL,	NULL,	NULL,	NULL),
(2,	'Half Board',	'Accommodation includes breakfast and lunch meals',	1,	NULL,	NULL,	NULL,	NULL),
(3,	'Full Board',	'Accommodation includes all meals',	1,	NULL,	NULL,	NULL,	NULL);

CREATE TABLE `report` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(140) NOT NULL,
  `slug` varchar(140) NOT NULL,
  `type` char(1) NOT NULL,
  `published` tinyint(4) NOT NULL DEFAULT '1',
  `fdesk_user` int(11) NOT NULL,
  `db_query` text,
  `allowed_users` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `report` (`id`, `name`, `slug`, `type`, `published`, `fdesk_user`, `db_query`, `allowed_users`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'Daily Summary',	'daily-summary',	'd',	1,	0,	NULL,	NULL,	NULL,	NULL,	NULL),
(2,	'Daily Settlement',	'daily-settlement',	'd',	1,	0,	NULL,	NULL,	NULL,	NULL,	NULL),
(3,	'Daily Outstanding',	'daily-outstanding',	'd',	1,	0,	NULL,	NULL,	NULL,	NULL,	NULL),
(4,	'Daily Expenses',	'daily-expenses',	'd',	1,	0,	NULL,	NULL,	NULL,	NULL,	NULL),
(5,	'Check In-Out and Stay Over',	'check-in-out-and-stay-over',	'd',	1,	0,	NULL,	NULL,	NULL,	NULL,	NULL),
(6,	'Room Availability',	'room-availability',	'd',	0,	0,	NULL,	NULL,	NULL,	NULL,	NULL),
(7,	'Guest Ledger',	'guest-ledger',	'd',	0,	0,	NULL,	NULL,	NULL,	NULL,	NULL),
(8,	'Room History',	'room-history',	'm',	1,	0,	NULL,	NULL,	NULL,	NULL,	NULL),
(9,	'Monthly Summary',	'monthly-summary',	'm',	1,	0,	NULL,	NULL,	NULL,	NULL,	NULL),
(10,	'Monthly Settlement',	'monthly-settlement',	'm',	1,	0,	NULL,	NULL,	NULL,	NULL,	NULL),
(11,	'Monthly Outstanding',	'monthly-outstanding',	'm',	1,	0,	NULL,	NULL,	NULL,	NULL,	NULL),
(12,	'Monthly Expenses',	'monthly-expenses',	'm',	1,	0,	NULL,	NULL,	NULL,	NULL,	NULL),
(13,	'Room Revenue',	'room-revenue',	'm',	0,	0,	NULL,	NULL,	NULL,	NULL,	NULL),
(14,	'Monthly Statistics',	'monthly-statistics',	'm',	0,	0,	NULL,	NULL,	NULL,	NULL,	NULL),
(15,	'Monthly Inventory',	'monthly-inventory',	'm',	0,	0,	NULL,	NULL,	NULL,	NULL,	NULL);

CREATE TABLE `report_period` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `acctg_method` char(1) NOT NULL,
  `description` varchar(255) NOT NULL,
  `report_type` char(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `room` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `room_type` int(11) NOT NULL,
  `alias` varchar(20) DEFAULT NULL,
  `status` char(3) NOT NULL,
  `hk_status` char(3) NOT NULL,
  `is_rental` tinyint(4) NOT NULL DEFAULT '0',
  `deposit_required` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `room` (`id`, `name`, `room_type`, `alias`, `status`, `hk_status`, `is_rental`, `deposit_required`) VALUES
(1,	'101',	1,	'',	'VAC',	'CLN',	0,	0),
(2,	'102',	1,	'',	'VAC',	'CLN',	0,	0),
(3,	'103',	1,	'',	'VAC',	'CLN',	0,	0),
(4,	'104',	2,	'',	'VAC',	'CLN',	0,	0),
(5,	'105',	2,	'',	'OCC',	'CLN',	0,	0),
(6,	'106',	2,	'',	'VAC',	'CLN',	0,	0),
(7,	'107',	3,	'',	'VAC',	'CLN',	0,	0),
(8,	'108',	3,	'',	'VAC',	'CLN',	0,	0),
(9,	'109',	4,	'',	'VAC',	'CLN',	0,	0),
(10,	'110',	4,	'',	'VAC',	'CLN',	0,	0),
(11,	'201',	5,	'',	'VAC',	'CLN',	0,	0),
(12,	'202',	5,	'',	'VAC',	'CLN',	0,	0),
(13,	'203',	5,	'',	'VAC',	'CLN',	0,	0),
(14,	'204',	4,	'',	'VAC',	'CLN',	0,	0);

CREATE TABLE `room_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(140) NOT NULL,
  `description` text,
  `base_rate` decimal(10,0) NOT NULL DEFAULT '0',
  `is_rental` tinyint(4) NOT NULL DEFAULT '0',
  `deposit_required` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `room_type` (`id`, `name`, `description`, `base_rate`, `is_rental`, `deposit_required`) VALUES
(1,	'Deluxe Single',	'Spacious room with queen size bed, ensuite bathroom - plus hair dryer, iron, data point, flat screen TV with complimentary movie channels, coffee table, air condition and free wireless internet access.',	0,	0,	0),
(2,	'Deluxe Double',	'Spacious room with king-size bed, ensuite bathroom - plus hairdryer, iron, data point, flat-screen TV with complimentary movie channels, coffee table, air-condition and free wireless internet access.',	0,	0,	0),
(3,	'Double',	'Spacious room with queen size bed, ensuite bathroom - plus hairdryer, iron, data point, flat-screen TV with complimentary movie channels, coffee table, air-condition and free wireless internet access.',	0,	0,	0),
(4,	'Twin Bed',	'2 Single beds, ensuite bathroom, air-condition, LCD TV, Complimentary movie channel and free wireless internet access.',	0,	0,	0),
(5,	'Single',	'Spacious rooms with 1 single bed and ensuite bathroom, air-condition, LCD TV, Complimentary movie channels and free wireless internet access.',	0,	0,	0);

CREATE TABLE `salary_component` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(140) NOT NULL,
  `description` text,
  `enabled` tinyint(1) DEFAULT '1',
  `is_payable` tinyint(1) DEFAULT '1',
  `is_tax_applicable` tinyint(1) DEFAULT '1',
  `depends_on_payment_days` tinyint(1) DEFAULT '0',
  `type` varchar(140) NOT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `salary_slip` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(140) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `designation` varchar(140) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` varchar(20) NOT NULL,
  `date_paid` date DEFAULT NULL,
  `date_due` date NOT NULL,
  `payroll_period` varchar(20) NOT NULL,
  `total_deductions` decimal(10,2) NOT NULL,
  `total_earnings` decimal(10,2) NOT NULL,
  `total_gross` decimal(10,2) NOT NULL,
  `net_amount` decimal(10,2) NOT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `deleted_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `sales_invoice` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_num` int(11) NOT NULL,
  `issue_date` date NOT NULL,
  `due_date` date NOT NULL,
  `status` char(1) NOT NULL,
  `source` varchar(140) NOT NULL,
  `source_id` int(11) NOT NULL,
  `customer_name` varchar(140) DEFAULT NULL,
  `unit_name` varchar(140) DEFAULT NULL,
  `amount_due` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `disc_total` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `tax_total` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `amount_paid` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `balance_due` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `advance_paid` decimal(15,4) DEFAULT NULL,
  `paid_status` char(2) NOT NULL,
  `billing_address` text,
  `po_number` varchar(10) DEFAULT NULL,
  `amounts_tax_inc` tinyint(4) DEFAULT '0',
  `summary` varchar(140) DEFAULT NULL,
  `notes` text,
  `fdesk_user` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `sales_invoice` (`id`, `invoice_num`, `issue_date`, `due_date`, `status`, `source`, `source_id`, `customer_name`, `unit_name`, `amount_due`, `disc_total`, `tax_total`, `amount_paid`, `balance_due`, `advance_paid`, `paid_status`, `billing_address`, `po_number`, `amounts_tax_inc`, `summary`, `notes`, `fdesk_user`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	1001,	'2020-02-28',	'2020-02-29',	'O',	'BKG',	3,	'Abdirizack Bare',	'104',	5650.0000,	0.0000,	0.0000,	0.0000,	5650.0000,	0.0000,	'NP',	'',	NULL,	0,	'',	'',	1,	'2020-02-28 19:48:20',	'2020-03-27 14:44:10',	NULL);

CREATE TABLE `sales_invoice_item` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `gl_account_id` int(11) DEFAULT NULL,
  `description` text,
  `qty` decimal(12,4) NOT NULL,
  `unit_price` decimal(12,4) NOT NULL,
  `discount_percent` decimal(12,4) DEFAULT NULL,
  `amount` decimal(10,0) NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `sales_invoice_item` (`id`, `item_id`, `invoice_id`, `gl_account_id`, `description`, `qty`, `unit_price`, `discount_percent`, `amount`, `deleted_at`) VALUES
(1,	1,	1,	NULL,	'Accommodation for unit no. 104',	1.0000,	4800.0000,	0.0000,	4800,	NULL),
(2,	1,	1,	NULL,	'Accommodation for unit no. 104',	1.0000,	4800.0000,	0.0000,	4800,	'2020-03-27 14:47:49'),
(3,	2,	1,	NULL,	'',	1.0000,	350.0000,	0.0000,	350,	'2020-03-27 14:44:10');

CREATE TABLE `sales_payment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `receipt_number` int(11) NOT NULL,
  `bill_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `payer` varchar(140) NOT NULL,
  `payment_method` varchar(140) NOT NULL,
  `reference` varchar(140) NOT NULL,
  `attachment` varchar(140) NOT NULL,
  `status` varchar(140) NOT NULL,
  `gl_account_id` int(11) DEFAULT NULL,
  `amount` decimal(10,0) NOT NULL,
  `tax_id` int(11) DEFAULT NULL,
  `bank_account_id` int(11) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `service_item` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `service_type` int(11) NOT NULL,
  `gl_account_id` int(11) DEFAULT NULL,
  `description` varchar(140) DEFAULT NULL,
  `qty` int(4) DEFAULT NULL,
  `unit_price` double DEFAULT NULL,
  `discount_percent` double DEFAULT NULL,
  `billable` tinyint(1) DEFAULT '1',
  `enabled` tinyint(1) DEFAULT '1',
  `fdesk_user` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `service_item` (`id`, `code`, `service_type`, `gl_account_id`, `description`, `qty`, `unit_price`, `discount_percent`, `billable`, `enabled`, `fdesk_user`, `created_at`, `updated_at`) VALUES
(1,	'Rm-APN',	1,	NULL,	'Accommodation per night',	1,	0,	NULL,	1,	1,	1,	NULL,	NULL),
(2,	'RmS-MO',	16,	NULL,	'Room service on meal order',	1,	300,	NULL,	1,	1,	1,	NULL,	NULL),
(3,	'GL-SSS',	8,	NULL,	'Shirts (short sleeves), Dry-cleaning',	1,	150,	NULL,	1,	1,	0,	NULL,	NULL),
(4,	'Rm-APH',	1,	NULL,	'Accommodation per hr (daytime)',	1,	500,	NULL,	1,	1,	1,	NULL,	NULL);

CREATE TABLE `service_items` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(20) NOT NULL,
  `gl_account_id` int(11) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `qty` int(4) NOT NULL,
  `unit_price` double DEFAULT NULL,
  `discount_percent` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `service_types` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(140) NOT NULL,
  `code` varchar(20) NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `is_default` tinyint(1) DEFAULT '0',
  `parent_id` int(11) DEFAULT NULL,
  `default_service_provider` int(11) DEFAULT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `service_types` (`id`, `name`, `code`, `enabled`, `is_default`, `parent_id`, `default_service_provider`, `fdesk_user`, `created_at`, `updated_at`) VALUES
(1,	'Accommodation',	'ACCOM',	1,	0,	12,	NULL,	1,	1582800594,	1583099034),
(2,	'Rental',	'RENT',	1,	0,	12,	NULL,	1,	1582801120,	1583099074),
(3,	'Hire',	'HIRE',	1,	0,	12,	NULL,	1,	1582802167,	1583099055),
(4,	'House Keeping',	'HK',	1,	0,	0,	NULL,	1,	1582802185,	1583098870),
(5,	'Food & Beverages',	'F&B',	1,	0,	0,	NULL,	1,	1582802215,	1583093935),
(6,	'Laundry',	'LAUNDRY',	1,	0,	0,	NULL,	1,	1582802308,	1583095184),
(7,	'Hotel Laundry',	'HOT LDRY',	1,	0,	6,	NULL,	1,	1582802339,	1583098965),
(8,	'Guest Laundry',	'GST LDRY',	1,	0,	6,	NULL,	1,	1582803016,	1583098978),
(9,	'Transport',	'TRANS',	0,	0,	NULL,	NULL,	1,	1582803271,	1582803271),
(10,	'Daily Linen',	'DL',	1,	0,	6,	NULL,	1,	1583094330,	1583094330),
(11,	'Laundry Items',	'LI',	1,	0,	6,	NULL,	1,	1583094346,	1583094357),
(12,	'Frontdesk',	'FD',	1,	0,	0,	NULL,	1,	1583095993,	1583096001),
(13,	'Breakfast, Buffet',	'BB',	1,	0,	5,	NULL,	1,	1583160258,	1583160378),
(14,	'Lunch, Buffet',	'BL',	1,	0,	5,	NULL,	1,	1583160321,	1583160321),
(15,	'DInner, Buffet',	'BD',	1,	0,	5,	NULL,	1,	1583160346,	1583160346),
(16,	'À la carte',	'ALA',	1,	0,	5,	NULL,	1,	1583160567,	1583160567);

CREATE TABLE `summary` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `units_sold` int(11) NOT NULL,
  `units_blocked` int(11) NOT NULL DEFAULT '0',
  `complimentary_units` int(11) NOT NULL DEFAULT '0',
  `no_of_guests` int(10) NOT NULL,
  `opening_bal` decimal(10,0) NOT NULL,
  `rent_total` decimal(10,0) NOT NULL,
  `discount_total` decimal(10,0) NOT NULL,
  `settlement_total` decimal(10,0) NOT NULL,
  `expense_total` decimal(10,0) NOT NULL,
  `deposits_total` decimal(10,0) NOT NULL,
  `closing_bal` decimal(10,0) NOT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `task_checklists` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `heading` text NOT NULL,
  `content` text NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `taxes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(140) NOT NULL,
  `type` varchar(140) DEFAULT NULL,
  `rate` decimal(10,0) NOT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT '1',
  `fdesk_user` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `taxes` (`id`, `code`, `name`, `type`, `rate`, `enabled`, `fdesk_user`, `created_at`, `updated_at`) VALUES
(1,	'Vat',	'Value-added tax',	'Normal',	16,	1,	0,	'0000-00-00 00:00:00',	'2020-03-15 00:04:58'),
(2,	'CL',	'Catering Levy',	'Inclusive',	2,	0,	1,	'0000-00-00 00:00:00',	'2020-03-15 00:05:16');

CREATE TABLE `timesheet` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `timesheet_entry` (
  `id` int(11) NOT NULL,
  `timesheet_id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `amount` double(10,2) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `unit` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `prefix` varchar(20) DEFAULT NULL,
  `name` varchar(20) NOT NULL,
  `unit_type` int(11) NOT NULL,
  `status` char(3) NOT NULL,
  `hk_status` char(3) NOT NULL,
  `fdesk_user` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `unit` (`id`, `prefix`, `name`, `unit_type`, `status`, `hk_status`, `fdesk_user`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'',	'101',	1,	'VAC',	'CLN',	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL),
(2,	'',	'102',	1,	'VAC',	'CLN',	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL),
(3,	'',	'103',	2,	'VAC',	'CLN',	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL),
(4,	'',	'104',	2,	'OCC',	'CLN',	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL),
(5,	'',	'105',	3,	'VAC',	'CLN',	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL),
(6,	'',	'106',	4,	'VAC',	'CLN',	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL),
(7,	'',	'107',	4,	'VAC',	'CLN',	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL),
(8,	'',	'108',	5,	'VAC',	'CLN',	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL),
(9,	'',	'109',	5,	'VAC',	'CLN',	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL),
(10,	'',	'306',	6,	'VAC',	'CLN',	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL);

CREATE TABLE `unit_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `property_id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL,
  `description` text,
  `alias` varchar(140) DEFAULT NULL,
  `base_rate` decimal(10,0) NOT NULL DEFAULT '0',
  `used_for` char(3) NOT NULL,
  `inactive` tinyint(4) DEFAULT '0',
  `ota_mappings` text,
  `amenities` text,
  `image_path` varchar(140) DEFAULT NULL,
  `fdesk_user` int(11) NOT NULL,
  `max_persons` int(11) NOT NULL,
  `default_pax` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `unit_type` (`id`, `code`, `property_id`, `name`, `description`, `alias`, `base_rate`, `used_for`, `inactive`, `ota_mappings`, `amenities`, `image_path`, `fdesk_user`, `max_persons`, `default_pax`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'DS',	3,	'Deluxe Single',	'Spacious room with queen size bed, ensuite bathroom - plus hairdryer, iron, data point, flat-screen TV with complimentary movie channels, coffee table, air-condition and free wireless internet access.',	'Room',	0,	'A',	0,	NULL,	NULL,	'',	1,	3,	2,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL),
(2,	'DD',	3,	'Deluxe Double',	'Spacious room with king-size bed, ensuite bathroom - plus hairdryer, iron, data point, flat-screen TV with complimentary movie channels, coffee table, air-condition and free wireless internet access.',	'Room',	0,	'A',	0,	NULL,	NULL,	NULL,	1,	4,	2,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL),
(3,	'D',	3,	'Double',	'Spacious room with queen size bed, ensuite bathroom - plus hairdryer, iron, data point, flat-screen TV with complimentary movie channels, coffee table, air-condition and free wireless internet access.',	'Room',	0,	'A',	0,	NULL,	NULL,	NULL,	1,	2,	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL),
(4,	'TB',	3,	'Twin Bed',	'2 Single beds, ensuite bathroom, air-condition, LCD TV, Complimentary movie channel and free wireless internet access.',	'Room',	0,	'A',	0,	NULL,	NULL,	'uploads/suhufi_twin_room.jpg',	1,	2,	2,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL),
(5,	'S',	3,	'Single',	'Spacious rooms with 1 single bed and ensuite bathroom, air-condition, LCD TV, Complimentary movie channels and free wireless internet access.',	'Room',	0,	'A',	0,	NULL,	NULL,	NULL,	1,	1,	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL),
(6,	'OS-S',	1,	'Office Space (Small)',	'Office space on the 1st, 2nd, and 3rd floors with shared washrooms and limited front parking',	'Room',	16000,	'R',	1,	NULL,	NULL,	NULL,	1,	0,	0,	'0000-00-00 00:00:00',	'2020-03-10 13:15:00',	NULL),
(7,	'2BF',	2,	'2-bedroom Flat',	'',	'Apartment',	0,	'A',	1,	NULL,	NULL,	NULL,	1,	6,	1,	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	NULL);

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `last_login` varchar(25) NOT NULL,
  `previous_login` varchar(25) NOT NULL DEFAULT '0',
  `login_hash` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`,`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `username`, `password`, `group_id`, `email`, `last_login`, `previous_login`, `login_hash`, `user_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(0,	'guest',	'YOU CAN NOT USE THIS TO LOGIN',	2,	'',	'0',	'0',	'',	0,	1581018388,	0,	NULL),
(2,	'superadmin',	'Cn3U2vAhxMgwMDehTzy0YZGJfBrcjq8edi5lsEJ2fuQ=',	6,	'superadmin@example.com',	'1585319351',	'1585312837',	'c186dbf2602be1741b0b1f0c196bbda7e39db38b',	2,	1585312779,	1585319351,	NULL),
(3,	'admin',	'Cn3U2vAhxMgwMDehTzy0YZGJfBrcjq8edi5lsEJ2fuQ=',	5,	'admin@example.com',	'1590062095',	'1590061692',	'6e500cbea43fd71b2ce95fc2e14455bb3d029bc5',	3,	1585313190,	1590062095,	NULL),
(4,	'user',	'Cn3U2vAhxMgwMDehTzy0YZGJfBrcjq8edi5lsEJ2fuQ=',	3,	'user@example.com',	'1585346376',	'1585319323',	'7033fd751c454c740fd721c87f628583e31116fb',	4,	1585313239,	1585346376,	NULL);

CREATE TABLE `users_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '',
  `client_id` varchar(32) NOT NULL DEFAULT '',
  `client_secret` varchar(32) NOT NULL DEFAULT '',
  `redirect_uri` varchar(255) NOT NULL DEFAULT '',
  `auto_approve` tinyint(1) NOT NULL DEFAULT '0',
  `autonomous` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('development','pending','approved','rejected') NOT NULL DEFAULT 'development',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `notes` tinytext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `client_id` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `users_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users_groups` (`id`, `name`, `user_id`, `created_at`, `updated_at`) VALUES
(1,	'Banned',	0,	0,	0),
(2,	'Guests',	0,	0,	0),
(3,	'Users',	0,	0,	0),
(4,	'Moderators',	0,	0,	0),
(5,	'Administrators',	0,	0,	0),
(6,	'Super Admins',	0,	0,	0);

CREATE TABLE `users_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `perms_id` int(11) NOT NULL,
  `actions` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `users_group_roles` (
  `group_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`group_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users_group_roles` (`group_id`, `role_id`) VALUES
(1,	1),
(2,	2),
(3,	3),
(4,	3),
(4,	4),
(5,	3),
(5,	4),
(5,	5),
(6,	6);

CREATE TABLE `users_metadata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `key` varchar(20) NOT NULL,
  `value` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users_metadata` (`id`, `parent_id`, `key`, `value`, `user_id`, `created_at`, `updated_at`) VALUES
(2,	0,	'fullname',	'Guest',	0,	0,	0),
(10,	2,	'fullname',	'Super admin',	1,	1585312779,	0),
(11,	2,	'mobile',	'0801234567',	2,	1585312779,	1585312868),
(12,	3,	'fullname',	'Administrator',	2,	1585313190,	0),
(13,	3,	'mobile',	'0712345678',	2,	1585313190,	0),
(14,	4,	'fullname',	'User',	3,	1585313239,	0),
(15,	4,	'mobile',	'',	3,	1585313239,	0);

CREATE TABLE `users_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `area` varchar(25) NOT NULL,
  `permission` varchar(25) NOT NULL,
  `description` varchar(255) NOT NULL,
  `actions` text,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `permission` (`area`,`permission`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `users_providers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `provider` varchar(50) NOT NULL,
  `uid` varchar(255) NOT NULL,
  `secret` varchar(255) DEFAULT NULL,
  `access_token` varchar(255) DEFAULT NULL,
  `expires` int(12) DEFAULT '0',
  `refresh_token` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `users_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `filter` enum('','A','D','R') NOT NULL DEFAULT '',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users_roles` (`id`, `name`, `filter`, `user_id`, `created_at`, `updated_at`) VALUES
(1,	'banned',	'D',	0,	0,	0),
(2,	'public',	'',	0,	0,	0),
(3,	'user',	'',	0,	0,	0),
(4,	'moderator',	'',	0,	0,	0),
(5,	'administrator',	'',	0,	0,	0),
(6,	'superadmin',	'A',	0,	0,	0);

CREATE TABLE `users_role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `perms_id` int(11) NOT NULL,
  `actions` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `users_scopes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scope` varchar(64) NOT NULL DEFAULT '',
  `name` varchar(64) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `scope` (`scope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `users_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` varchar(32) NOT NULL DEFAULT '',
  `redirect_uri` varchar(255) NOT NULL DEFAULT '',
  `type_id` varchar(64) NOT NULL,
  `type` enum('user','auto') NOT NULL DEFAULT 'user',
  `code` text NOT NULL,
  `access_token` varchar(50) NOT NULL DEFAULT '',
  `stage` enum('request','granted') NOT NULL DEFAULT 'request',
  `first_requested` int(11) NOT NULL,
  `last_updated` int(11) NOT NULL,
  `limited_access` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `oauth_sessions_ibfk_1` (`client_id`),
  CONSTRAINT `oauth_sessions_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `users_clients` (`client_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `users_sessionscopes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` int(11) NOT NULL,
  `access_token` varchar(50) NOT NULL DEFAULT '',
  `scope` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`),
  KEY `access_token` (`access_token`),
  KEY `scope` (`scope`),
  CONSTRAINT `oauth_sessionscopes_ibfk_1` FOREIGN KEY (`scope`) REFERENCES `users_scopes` (`scope`),
  CONSTRAINT `oauth_sessionscopes_ibfk_2` FOREIGN KEY (`session_id`) REFERENCES `users_sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `users_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `perms_id` int(11) NOT NULL,
  `actions` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `users_user_roles` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2020-05-21 12:03:28
